'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Menu, X, Home, ShoppingCart, FileText, TrendingUp, Leaf, AlertCircle, LogOut } from 'lucide-react';

interface NavbarProps {
  userType: 'farmer' | 'buyer' | 'admin';
  userName?: string;
}

export default function Navbar({ userType, userName = 'User' }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const farmerLinks = [
    { href: '/dashboard/farmer', label: 'Dashboard', icon: Home },
    { href: '/marketplace', label: 'Marketplace', icon: ShoppingCart },
    { href: '/my-contracts', label: 'Contracts', icon: FileText },
    { href: '/analytics', label: 'Analytics', icon: TrendingUp },
    { href: '/schemes-news', label: 'Schemes & News', icon: Leaf },
  ];

  const buyerLinks = [
    { href: '/dashboard/buyer', label: 'Dashboard', icon: Home },
    { href: '/buyer-marketplace', label: 'Browse Farmers', icon: ShoppingCart },
    { href: '/buyer-bids', label: 'My Bids', icon: TrendingUp },
    { href: '/my-contracts', label: 'Contracts', icon: FileText },
    { href: '/schemes-news', label: 'Market News', icon: AlertCircle },
  ];

  const links = userType === 'farmer' ? farmerLinks : buyerLinks;

  const handleLogout = () => {
    window.location.href = '/';
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-white border-b border-[#E8ECEF] shadow-sm animate-slide-down">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href={userType === 'farmer' ? '/dashboard/farmer' : userType === 'buyer' ? '/dashboard/buyer' : '/admin/dashboard'}>
            <div className="flex items-center gap-2 group">
              <div className="p-2 bg-[#1E7F43] rounded-lg group-hover:bg-[#165a33] transition-all duration-300">
                <Leaf className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-[#1F2933] hidden md:inline">ArgiSetu</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-1">
            {links.map((link) => {
              const Icon = link.icon;
              return (
                <Link key={link.href} href={link.href}>
                  <div className="flex items-center gap-2 px-3 py-2 text-[#8B95A5] hover:text-[#1E7F43] hover:bg-[#F4F8F5] rounded-lg transition-all duration-200">
                    <Icon size={18} />
                    <span className="text-sm font-medium">{link.label}</span>
                  </div>
                </Link>
              );
            })}
          </div>

          {/* Right Side */}
          <div className="flex items-center gap-4">
            {/* User Info */}
            <div className="hidden md:flex items-center gap-3 px-3 py-2 bg-[#F4F8F5] rounded-lg">
              <div className="w-8 h-8 bg-[#1E7F43] rounded-full flex items-center justify-center text-white text-sm font-bold animate-fade-in">
                {userName.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="text-sm font-semibold text-[#1F2933]">{userName}</p>
                <p className="text-xs text-[#8B95A5] capitalize">{userType}</p>
              </div>
            </div>

            {/* Logout Button */}
            <button
              onClick={handleLogout}
              className="hidden md:flex items-center gap-2 px-3 py-2 text-[#DC2626] hover:bg-red-50 rounded-lg transition-all duration-200 text-sm font-medium"
            >
              <LogOut size={18} />
              <span>Logout</span>
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2 hover:bg-[#F4F8F5] rounded-lg transition-all duration-200"
            >
              {isOpen ? <X size={24} className="text-[#1F2933]" /> : <Menu size={24} className="text-[#1F2933]" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden border-t border-[#E8ECEF] py-4 animate-slide-down">
            {links.map((link) => {
              const Icon = link.icon;
              return (
                <Link key={link.href} href={link.href} onClick={() => setIsOpen(false)}>
                  <div className="flex items-center gap-3 px-4 py-3 text-[#8B95A5] hover:text-[#1E7F43] hover:bg-[#F4F8F5] transition-all duration-200">
                    <Icon size={20} />
                    <span className="font-medium">{link.label}</span>
                  </div>
                </Link>
              );
            })}
            <button
              onClick={() => {
                setIsOpen(false);
                handleLogout();
              }}
              className="w-full flex items-center gap-3 px-4 py-3 text-[#DC2626] hover:bg-red-50 transition-all duration-200 font-medium mt-4 border-t border-[#E8ECEF]"
            >
              <LogOut size={20} />
              <span>Logout</span>
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
