'use client';

import { useState } from 'react';
import Navbar from '@/components/navbar';
import { ArrowLeft, Trash2, Check, X } from 'lucide-react';
import Link from 'next/link';

export default function Notifications() {
  const [notifications, setNotifications] = useState([
    { id: 1, type: 'bid', title: 'New Bid Received', message: 'You received a new bid on Wheat (500kg) from ABC Trading', time: '5 minutes ago', read: false, icon: '🎯' },
    { id: 2, type: 'contract', title: 'Contract Accepted', message: 'Your contract for Rice (1000kg) has been accepted by XYZ Dealers', time: '2 hours ago', read: false, icon: '✓' },
    { id: 3, type: 'payment', title: 'Payment Received', message: 'Payment of ₹45,600 has been credited to your account', time: '1 day ago', read: true, icon: '₹' },
    { id: 4, type: 'scheme', title: 'New Government Scheme', message: 'PM-KISAN Yojana extended. Check eligibility and apply now', time: '2 days ago', read: true, icon: '🏛️' },
    { id: 5, type: 'market', title: 'Market Price Update', message: 'Wheat prices increased by 8% in your region', time: '3 days ago', read: true, icon: '📈' },
    { id: 6, type: 'bid', title: 'Bid Placed Successfully', message: 'You placed a bid on Cotton (750kg) for ₹52,000', time: '4 days ago', read: true, icon: '🎯' },
  ]);

  const markAsRead = (id) => {
    setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const deleteNotification = (id) => {
    setNotifications(notifications.filter(n => n.id !== id));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="min-h-screen bg-[#F4F8F5]">
      <Navbar userType="farmer" userName="Harjeet" />
      
      <main className="max-w-4xl mx-auto px-4 py-8 pt-24">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 animate-fade-in">
          <div className="flex items-center gap-4">
            <Link href="/dashboard/farmer">
              <button className="p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow">
                <ArrowLeft size={20} className="text-[#1E7F43]" />
              </button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-[#1F2933]">Notifications</h1>
              {unreadCount > 0 && <p className="text-sm text-[#8B95A5]">{unreadCount} unread</p>}
            </div>
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {notifications.length > 0 ? (
            notifications.map((notification, idx) => (
              <div
                key={notification.id}
                className={`p-4 rounded-xl border transition-all duration-300 animate-slide-up hover:shadow-lg ${
                  notification.read
                    ? 'bg-white border-[#E8ECEF] hover:border-[#A7E3C1]'
                    : 'bg-[#F4F8F5] border-[#1E7F43] hover:border-[#1E7F43]'
                }`}
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div className="flex items-start gap-4">
                  {/* Icon */}
                  <div className="text-2xl mt-1 flex-shrink-0">{notification.icon}</div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <h3 className={`font-bold ${notification.read ? 'text-[#1F2933]' : 'text-[#1E7F43]'}`}>
                          {notification.title}
                        </h3>
                        <p className="text-sm text-[#8B95A5] mt-1">{notification.message}</p>
                        <p className="text-xs text-[#8B95A5] mt-2">{notification.time}</p>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {!notification.read && (
                          <button
                            onClick={() => markAsRead(notification.id)}
                            className="p-2 hover:bg-[#1E7F43]/10 rounded-lg transition-all duration-300 tooltip"
                            title="Mark as read"
                          >
                            <Check size={18} className="text-[#1E7F43]" />
                          </button>
                        )}
                        <button
                          onClick={() => deleteNotification(notification.id)}
                          className="p-2 hover:bg-red-50 rounded-lg transition-all duration-300 tooltip"
                          title="Delete"
                        >
                          <Trash2 size={18} className="text-red-500" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-16 bg-white rounded-2xl border border-[#E8ECEF]">
              <div className="text-5xl mb-4">📭</div>
              <h3 className="text-lg font-bold text-[#1F2933] mb-2">No Notifications</h3>
              <p className="text-[#8B95A5]">You are all caught up!</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
