'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Leaf, Building2, Settings, FileText, TrendingUp, Eye, CheckCircle2, ArrowRight } from 'lucide-react';

export default function LandingPage() {
  const [adminHovered, setAdminHovered] = useState(false);
  const [farmersCount, setFarmersCount] = useState(0);
  const [contractsCount, setContractsCount] = useState(0);
  const [cropsCount, setCropsCount] = useState(0);
  const [priceGainCount, setPriceGainCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setFarmersCount((prev) => (prev < 5000 ? prev + 100 : prev));
      setContractsCount((prev) => (prev < 12000 ? prev + 200 : prev));
      setCropsCount((prev) => (prev < 45000 ? prev + 1000 : prev));
      setPriceGainCount((prev) => (prev < 28 ? prev + 0.5 : prev));
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const features = [
    { icon: FileText, title: 'Digital Contracts', description: 'Secure, paperless agreements' },
    { icon: TrendingUp, title: 'Fair Price Discovery', description: 'Live market benchmarking' },
    { icon: Eye, title: 'Full Transparency', description: 'Track every step from farm to buyer' },
  ];

  const timeline = [
    { step: 'Farmer lists crop', icon: '📋' },
    { step: 'Buyer places bid', icon: '🎯' },
    { step: 'Price negotiated', icon: '💰' },
    { step: 'Contract signed', icon: '✍️' },
    { step: 'Crop tracked', icon: '📍' },
    { step: 'Payment released', icon: '✅' },
  ];

  const schemes = [
    { title: 'PM-KISAN', benefit: '₹6000/year direct support' },
    { title: 'Soil Health Scheme', benefit: 'Free soil testing & advice' },
    { title: 'Crop Insurance', benefit: 'Up to 80% loss coverage' },
  ];

  return (
    <div className="min-h-screen bg-[#F4F8F5]">
      {/* Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-[#E8ECEF] animate-slide-down">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 text-[#1E7F43] font-bold text-xl hover:opacity-80 transition-opacity">
            <Leaf size={28} />
            <span>ArgiSetu</span>
          </Link>
          <div className="flex gap-4">
            <button className="px-6 py-2 text-[#1E7F43] font-semibold border border-[#1E7F43] rounded-lg hover:bg-[#F4F8F5] transition-all duration-300">
              Log In
            </button>
            <button className="px-6 py-2 bg-[#1E7F43] text-white font-semibold rounded-lg hover:bg-[#165a33] transition-all duration-300 button-ripple">
              Sign Up
            </button>
          </div>
        </div>
      </nav>

      {/* Hidden Admin Entry */}
      <button
        onClick={() => window.location.href = '/admin/login'}
        onMouseEnter={() => setAdminHovered(true)}
        onMouseLeave={() => setAdminHovered(false)}
        className="fixed top-24 right-6 z-40 p-2 rounded-full transition-all duration-300"
        title="Admin Access"
      >
        <Settings
          size={18}
          className={`transition-all duration-300 ${
            adminHovered ? 'text-[#1E7F43] rotate-45' : 'text-[#A7E3C1]/40'
          }`}
        />
      </button>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 min-h-screen flex items-center justify-center relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 w-72 h-72 bg-[#A7E3C1]/5 rounded-full blur-3xl animate-float" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#6BCF9B]/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 max-w-6xl text-center">
          {/* Main Headline */}
          <h1 className="text-6xl md:text-7xl font-bold text-[#1F2933] mb-6 animate-fade-in leading-tight">
            Connecting Farmers & Buyers
            <br />
            <span className="text-[#1E7F43]">for a Stable Future.</span>
          </h1>
          
          {/* Subtext */}
          <p className="text-xl text-[#8B95A5] max-w-2xl mx-auto mb-12 animate-slide-up">
            Secure contracts. Fair prices. Transparent supply chain.
          </p>

          {/* Role Selection Cards - 50-50 Layout */}
          <div className="grid md:grid-cols-2 gap-6 max-w-3xl mx-auto mb-16">
            {/* Farmer Card */}
            <Link href="/auth/farmer/phone">
              <div className="group relative h-full overflow-hidden rounded-2xl bg-white/40 backdrop-blur-md border border-white/60 p-8 transition-all duration-500 hover:scale-105 cursor-pointer animate-slide-up hover:shadow-2xl hover:border-[#1E7F43]/30">
                <div className="absolute inset-0 bg-gradient-to-br from-[#1E7F43]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative z-10">
                  <div className="p-4 bg-[#1E7F43]/10 rounded-xl w-fit mx-auto mb-6 group-hover:bg-[#1E7F43]/20 transition-all duration-300">
                    <Leaf size={32} className="text-[#1E7F43]" />
                  </div>
                  
                  <h2 className="text-2xl font-bold text-[#1F2933] mb-4">Farmer</h2>
                  <p className="text-[#8B95A5] text-sm mb-6">Direct access to verified buyers with guaranteed fair prices</p>
                  
                  <div className="space-y-2 text-sm text-left mb-6">
                    <div className="flex items-center gap-2 text-[#1F2933]">
                      <CheckCircle2 size={16} className="text-[#1E7F43]" />
                      <span>Assured buyer contracts</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1F2933]">
                      <CheckCircle2 size={16} className="text-[#1E7F43]" />
                      <span>Real-time market prices</span>
                    </div>
                  </div>
                  
                  <button className="w-full py-3 bg-[#1E7F43] text-white font-bold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 flex items-center justify-center gap-2 group-hover:shadow-lg">
                    Continue <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </Link>

            {/* Buyer Card */}
            <Link href="/auth/buyer/phone">
              <div className="group relative h-full overflow-hidden rounded-2xl bg-white/40 backdrop-blur-md border border-white/60 p-8 transition-all duration-500 hover:scale-105 cursor-pointer animate-slide-up hover:shadow-2xl hover:border-[#1E7F43]/30" style={{ animationDelay: '0.1s' }}>
                <div className="absolute inset-0 bg-gradient-to-br from-[#6BCF9B]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                
                <div className="relative z-10">
                  <div className="p-4 bg-[#6BCF9B]/10 rounded-xl w-fit mx-auto mb-6 group-hover:bg-[#6BCF9B]/20 transition-all duration-300">
                    <Building2 size={32} className="text-[#1E7F43]" />
                  </div>
                  
                  <h2 className="text-2xl font-bold text-[#1F2933] mb-4">Buyer (Dealer)</h2>
                  <p className="text-[#8B95A5] text-sm mb-6">Build reliable supply chains with verified farmers and full traceability</p>
                  
                  <div className="space-y-2 text-sm text-left mb-6">
                    <div className="flex items-center gap-2 text-[#1F2933]">
                      <CheckCircle2 size={16} className="text-[#1E7F43]" />
                      <span>Verified farmer network</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1F2933]">
                      <CheckCircle2 size={16} className="text-[#1E7F43]" />
                      <span>Full supply traceability</span>
                    </div>
                  </div>
                  
                  <button className="w-full py-3 bg-[#1E7F43] text-white font-bold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 flex items-center justify-center gap-2 group-hover:shadow-lg">
                    Continue <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Why ArgiSetu Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-[#1F2933] mb-16">Why ArgiSetu?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="p-8 rounded-2xl bg-[#F4F8F5] border border-[#E8ECEF] hover:border-[#1E7F43] transition-all duration-300 hover:shadow-lg animate-slide-up hover-lift" style={{ animationDelay: `${idx * 0.1}s` }}>
                  <div className="p-4 bg-white rounded-xl w-fit mb-6 group-hover:bg-[#1E7F43]/10">
                    <Icon size={32} className="text-[#1E7F43]" />
                  </div>
                  <h3 className="text-xl font-bold text-[#1F2933] mb-3">{feature.title}</h3>
                  <p className="text-[#8B95A5]">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 px-4 bg-[#F4F8F5]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-[#1F2933] mb-16">How It Works</h2>
          
          <div className="grid md:grid-cols-3 gap-6">
            {timeline.slice(0, 3).map((item, idx) => (
              <div key={idx} className="relative text-center animate-slide-up" style={{ animationDelay: `${idx * 0.1}s` }}>
                <div className="text-5xl mb-4">{item.icon}</div>
                <p className="font-semibold text-[#1F2933]">{item.step}</p>
                {idx < 2 && <div className="absolute right-0 top-12 w-12 h-1 bg-[#1E7F43] hidden md:block" />}
              </div>
            ))}
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 mt-8">
            {timeline.slice(3).map((item, idx) => (
              <div key={idx + 3} className="relative text-center animate-slide-up" style={{ animationDelay: `${(idx + 3) * 0.1}s` }}>
                <div className="text-5xl mb-4">{item.icon}</div>
                <p className="font-semibold text-[#1F2933]">{item.step}</p>
                {idx < 1 && <div className="absolute right-0 top-12 w-12 h-1 bg-[#1E7F43] hidden md:block" />}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Impact Metrics Section */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-[#1F2933] mb-16">ArgiSetu Impact</h2>
          
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center p-8 rounded-xl border border-[#E8ECEF] hover:border-[#1E7F43] hover:shadow-lg transition-all duration-300 animate-scale-in">
              <p className="text-5xl font-bold text-[#1E7F43] mb-2">{farmersCount.toLocaleString()}+</p>
              <p className="text-[#8B95A5] font-semibold">Farmers Onboarded</p>
            </div>
            <div className="text-center p-8 rounded-xl border border-[#E8ECEF] hover:border-[#1E7F43] hover:shadow-lg transition-all duration-300 animate-scale-in" style={{ animationDelay: '0.1s' }}>
              <p className="text-5xl font-bold text-[#1E7F43] mb-2">{contractsCount.toLocaleString()}+</p>
              <p className="text-[#8B95A5] font-semibold">Contracts Secured</p>
            </div>
            <div className="text-center p-8 rounded-xl border border-[#E8ECEF] hover:border-[#1E7F43] hover:shadow-lg transition-all duration-300 animate-scale-in" style={{ animationDelay: '0.2s' }}>
              <p className="text-5xl font-bold text-[#1E7F43] mb-2">{cropsCount.toLocaleString()}+</p>
              <p className="text-[#8B95A5] font-semibold">Crops Traded (MT)</p>
            </div>
            <div className="text-center p-8 rounded-xl border border-[#E8ECEF] hover:border-[#1E7F43] hover:shadow-lg transition-all duration-300 animate-scale-in" style={{ animationDelay: '0.3s' }}>
              <p className="text-5xl font-bold text-[#F4B400] mb-2">{priceGainCount.toFixed(0)}%</p>
              <p className="text-[#8B95A5] font-semibold">Avg. Price Gain</p>
            </div>
          </div>
        </div>
      </section>

      {/* Split Role Preview */}
      <section className="py-20 px-4 bg-[#F4F8F5]">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-[#1F2933] mb-16">Two Sides, One Platform</h2>
          
          <div className="grid md:grid-cols-2 gap-12">
            {/* Farmer Side */}
            <div className="p-10 rounded-2xl bg-white border border-[#E8ECEF] hover:border-[#1E7F43] transition-all duration-300 animate-slide-up hover-lift">
              <div className="flex items-center gap-3 mb-6">
                <Leaf size={32} className="text-[#1E7F43]" />
                <h3 className="text-2xl font-bold text-[#1F2933]">For Farmers</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-[#1E7F43] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-[#1F2933]">Predictable Income</p>
                    <p className="text-sm text-[#8B95A5]">Lock in prices before harvest</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-[#1E7F43] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-[#1F2933]">Direct Market Access</p>
                    <p className="text-sm text-[#8B95A5]">Connect with verified buyers</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-[#1E7F43] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-[#1F2933]">No Middlemen</p>
                    <p className="text-sm text-[#8B95A5]">Fair prices, transparent terms</p>
                  </div>
                </li>
              </ul>
            </div>

            {/* Buyer Side */}
            <div className="p-10 rounded-2xl bg-white border border-[#E8ECEF] hover:border-[#1E7F43] transition-all duration-300 animate-slide-up hover-lift" style={{ animationDelay: '0.1s' }}>
              <div className="flex items-center gap-3 mb-6">
                <Building2 size={32} className="text-[#1E7F43]" />
                <h3 className="text-2xl font-bold text-[#1F2933]">For Buyers</h3>
              </div>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-[#1E7F43] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-[#1F2933]">Reliable Supply</p>
                    <p className="text-sm text-[#8B95A5]">Guaranteed contracts with farmers</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-[#1E7F43] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-[#1F2933]">Verified Farmers</p>
                    <p className="text-sm text-[#8B95A5]">Quality assurance & credentials</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle2 size={20} className="text-[#1E7F43] mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-[#1F2933]">Traceable Produce</p>
                    <p className="text-sm text-[#8B95A5]">Farm-to-buyer full transparency</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* News & Schemes Teaser */}
      <section className="py-20 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-[#1F2933] mb-4">Government Support</h2>
          <p className="text-center text-[#8B95A5] mb-16 max-w-2xl mx-auto">Stay informed about new schemes and market opportunities</p>
          
          <div className="grid md:grid-cols-3 gap-6">
            {schemes.map((scheme, idx) => (
              <div key={idx} className="p-6 rounded-xl border border-[#E8ECEF] bg-[#F4F8F5] hover:border-[#1E7F43] transition-all duration-300 animate-slide-up" style={{ animationDelay: `${idx * 0.1}s` }}>
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-lg font-bold text-[#1F2933]">{scheme.title}</h3>
                  <div className="animate-soft-glow">⭐</div>
                </div>
                <p className="text-sm text-[#8B95A5]">{scheme.benefit}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 px-4 bg-[#F4F8F5]">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-5xl font-bold text-[#1F2933] mb-6 animate-fade-in">
            Join the Future of
            <br />
            <span className="text-[#1E7F43]">Contract Farming Today.</span>
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto mt-12">
            <Link href="/auth/farmer/phone">
              <button className="w-full py-4 bg-[#1E7F43] text-white font-bold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 shadow-lg hover:shadow-xl animate-slide-up">
                Continue as Farmer
              </button>
            </Link>
            <Link href="/auth/buyer/phone">
              <button className="w-full py-4 bg-[#F4B400] text-[#1F2933] font-bold rounded-lg button-ripple hover:bg-[#e0a200] transition-all duration-300 shadow-lg hover:shadow-xl animate-slide-up" style={{ animationDelay: '0.1s' }}>
                Continue as Buyer
              </button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#E8ECEF] bg-white py-8 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-[#8B95A5] text-sm">
            ArgiSetu – Assured Contract Farming System | Secure. Fair. Transparent.
          </p>
        </div>
      </footer>
    </div>
  );
}
