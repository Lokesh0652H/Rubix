'use client';

import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { AlertCircle, Home, RefreshCw } from 'lucide-react';
import { Suspense } from 'react';
import Loading from './loading'; // Import the Loading component

function ErrorContent() {
  const searchParams = useSearchParams();
  const title = searchParams.get('title') || 'Something went wrong';
  const message = searchParams.get('message') || 'An unexpected error occurred. Please try again.';
  const redirect = searchParams.get('redirect') || '/';

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center px-4">
      <div className="text-center max-w-md animate-fade-in">
        <div className="mb-6 flex justify-center">
          <div className="p-4 bg-red-50 rounded-full animate-scale-in">
            <AlertCircle size={64} className="text-red-500" />
          </div>
        </div>
        
        <h1 className="text-4xl font-bold text-[#1F2933] mb-4">{title}</h1>
        <p className="text-[#8B95A5] mb-8">{message}</p>
        
        <div className="flex gap-3">
          <button
            onClick={() => window.location.reload()}
            className="flex items-center justify-center gap-2 px-6 py-3 border border-red-500 text-red-500 rounded-lg font-semibold hover:bg-red-50 transition-all duration-300 flex-1"
          >
            <RefreshCw size={18} />
            Retry
          </button>
          <Link href={redirect} className="flex-1">
            <button className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300">
              <Home size={18} />
              Home
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function ErrorPage() {
  return (
    <Suspense fallback={<Loading />}> {/* Use the Loading component as fallback */}
      <ErrorContent />
    </Suspense>
  );
}
