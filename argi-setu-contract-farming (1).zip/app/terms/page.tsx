'use client';

import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export default function Terms() {
  return (
    <div className="min-h-screen bg-[#F4F8F5]">
      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-fade-in">
          <Link href="/">
            <button className="p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow">
              <ArrowLeft size={20} className="text-[#1E7F43]" />
            </button>
          </Link>
          <h1 className="text-4xl font-bold text-[#1F2933]">Terms & Conditions</h1>
        </div>

        {/* Content */}
        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 animate-slide-up space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">1. Agreement to Terms</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              By accessing and using the ArgiSetu platform, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">2. User Responsibilities</h2>
            <p className="text-[#8B95A5] leading-relaxed mb-4">
              As a user, you are responsible for:
            </p>
            <ul className="text-[#8B95A5] space-y-2 ml-4">
              <li>• Maintaining the confidentiality of your account information</li>
              <li>• Being responsible for all activity that occurs under your account</li>
              <li>• Providing accurate and truthful information during registration</li>
              <li>• Complying with all applicable laws and regulations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">3. Contract Terms</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              All contracts created through ArgiSetu are binding agreements between farmers and buyers. Both parties agree to honor the terms specified in the contract, including delivery dates, quality standards, and payment terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">4. Dispute Resolution</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              In case of disputes, both parties agree to submit to ArgiSetu's dispute resolution process. The platform's admin team will review all evidence and make fair determinations based on contract terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">5. Payment & Escrow</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              Payments are held in escrow until delivery is confirmed by both parties. ArgiSetu is not responsible for payment delays caused by banking systems or external factors.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">6. Limitation of Liability</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              ArgiSetu is provided "as is" without warranties of any kind. The platform shall not be liable for indirect, incidental, special, or consequential damages resulting from use of the service.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">7. Changes to Terms</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              ArgiSetu reserves the right to modify these terms at any time. Your continued use of the platform constitutes acceptance of modified terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">8. Contact Information</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              For questions regarding these terms, please contact us at legal@agrisetu.com or call +91 1234-567-890.
            </p>
          </section>

          <div className="border-t border-[#E8ECEF] pt-6 text-center text-sm text-[#8B95A5]">
            <p>Last Updated: January 2026</p>
          </div>
        </div>
      </div>
    </div>
  );
}
