'use client';

import React, { useState } from 'react';
import Navbar from '@/components/navbar';
import { Leaf, TrendingUp, AlertCircle, Calendar, DollarSign, BookOpen, Zap } from 'lucide-react';

interface Scheme {
  id: string;
  name: string;
  description: string;
  benefits: string[];
  eligibility: string;
  applicationDeadline: string;
  subsidyAmount: string;
  category: string;
}

interface MarketNews {
  id: string;
  title: string;
  content: string;
  crop: string;
  currentRate: string;
  trend: 'up' | 'down' | 'stable';
  trendPercent: string;
  date: string;
  source: string;
}

export default function SchemesAndNews() {
  const [activeTab, setActiveTab] = useState<'schemes' | 'news'>('schemes');

  const schemes: Scheme[] = [
    {
      id: '1',
      name: 'Prime Minister Fasal Bima Yojana (PMFBY)',
      description: 'Comprehensive crop insurance scheme to protect farmers against crop failure due to natural calamities',
      benefits: [
        'Insurance coverage up to 100% of crop value',
        'Premium subsidy of 50% for general farmers',
        '90% for backward/tribal regions',
        'Quick settlement of claims',
      ],
      eligibility: 'All farmers with landholding in notified areas',
      applicationDeadline: '2026-02-28',
      subsidyAmount: 'Up to ₹50,000 per hectare',
      category: 'Insurance',
    },
    {
      id: '2',
      name: 'Pradhan Mantri Krishi Sinchayee Yojana',
      description: 'Water irrigation improvement scheme to provide assured irrigation for agricultural lands',
      benefits: [
        'Micro irrigation equipment subsidy',
        'Drip irrigation systems at 50% cost',
        'Sprinkler systems support',
        'Water management training',
      ],
      eligibility: 'Farmers with cultivable land',
      applicationDeadline: '2026-03-31',
      subsidyAmount: 'Up to ₹1,00,000 per hectare',
      category: 'Irrigation',
    },
    {
      id: '3',
      name: 'Soil Health Card Scheme',
      description: 'Provides soil testing and personalized recommendations for nutrient management',
      benefits: [
        'Free soil testing',
        'Customized nutrient recommendations',
        'Improved crop yield',
        '30-40% reduction in fertilizer cost',
      ],
      eligibility: 'All farmers',
      applicationDeadline: '2026-04-15',
      subsidyAmount: 'Complimentary services',
      category: 'Soil Management',
    },
    {
      id: '4',
      name: 'Agricultural Infrastructure Development Fund',
      description: 'Supports development of agricultural infrastructure like cold chains and processing centers',
      benefits: [
        '3% interest rate subsidy',
        'Long-term loans up to ₹2 crore',
        'Minimal documentation',
        'Quick approval process',
      ],
      eligibility: 'Aggregators, Farmer groups, FPCs',
      applicationDeadline: '2026-05-31',
      subsidyAmount: 'Up to ₹2,00,00,000 loan',
      category: 'Infrastructure',
    },
  ];

  const marketNews: MarketNews[] = [
    {
      id: '1',
      title: 'Wheat Prices Rise 8% Following Strong Export Demand',
      content:
        'Wheat prices have surged 8% in the past week due to increased export inquiries from Middle Eastern countries. Farmers are advised to hold stock for better prices.',
      crop: 'Wheat',
      currentRate: '₹2,450/kg',
      trend: 'up',
      trendPercent: '+8.2%',
      date: '2026-01-18',
      source: 'National Commodities Exchange',
    },
    {
      id: '2',
      title: 'Rice Prices Stable Despite Global Competition',
      content:
        'Domestic rice prices remain stable despite competition from Vietnam and Thailand. Long-term contracts are recommended for price security.',
      crop: 'Rice',
      currentRate: '₹5,200/kg',
      trend: 'stable',
      trendPercent: '+0.5%',
      date: '2026-01-17',
      source: 'Ministry of Agriculture',
    },
    {
      id: '3',
      title: 'Cotton Demand Expected to Peak by March',
      content:
        'Textile mills are ramping up procurement for Q4. Expected peak demand in March suggests better prices. Consider staggered selling strategy.',
      crop: 'Cotton',
      currentRate: '₹6,100/kg',
      trend: 'up',
      trendPercent: '+5.3%',
      date: '2026-01-16',
      source: 'Textile Industry Association',
    },
    {
      id: '4',
      title: 'Government Announces Maize Support Price Increase',
      content:
        'Support price for maize increased to ₹2,100/kg for current season. Procurement operations begin from Feb 1. Farmers advised to contact nearest procurement centers.',
      crop: 'Maize',
      currentRate: '₹2,000/kg',
      trend: 'up',
      trendPercent: '+5.0%',
      date: '2026-01-15',
      source: 'Department of Agriculture',
    },
  ];

  const SchemeCard = ({ scheme, idx }: { scheme: Scheme; idx: number }) => (
    <div
      className="bg-white rounded-xl border border-[#E8ECEF] p-6 hover-lift transition-all duration-300 animate-slide-up"
      style={{ animationDelay: `${idx * 0.1}s` }}
    >
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-bold text-[#1F2933] mb-1">{scheme.name}</h3>
          <span className="inline-block px-3 py-1 bg-[#1E7F43]/10 text-[#1E7F43] rounded-full text-xs font-semibold">
            {scheme.category}
          </span>
        </div>
        <Leaf size={24} className="text-[#1E7F43]" />
      </div>

      <p className="text-[#8B95A5] text-sm mb-4">{scheme.description}</p>

      <div className="mb-4 pb-4 border-b border-[#E8ECEF]">
        <p className="text-sm font-semibold text-[#1F2933] mb-2">Key Benefits:</p>
        <ul className="space-y-1">
          {scheme.benefits.map((benefit, idx) => (
            <li key={idx} className="text-sm text-[#8B95A5] flex items-start gap-2">
              <span className="text-[#1E7F43] mt-1">✓</span>
              {benefit}
            </li>
          ))}
        </ul>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
        <div>
          <p className="text-[#8B95A5] text-xs mb-1">Eligibility</p>
          <p className="font-semibold text-[#1F2933]">{scheme.eligibility}</p>
        </div>
        <div>
          <p className="text-[#8B95A5] text-xs mb-1">Subsidy</p>
          <p className="font-bold text-[#1E7F43]">{scheme.subsidyAmount}</p>
        </div>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-[#E8ECEF]">
        <div className="flex items-center gap-2 text-xs text-[#8B95A5]">
          <Calendar size={16} />
          <span>Deadline: {scheme.applicationDeadline}</span>
        </div>
        <button className="px-4 py-2 bg-[#1E7F43] text-white font-semibold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 text-sm">
          Apply Now
        </button>
      </div>
    </div>
  );

  const NewsCard = ({ news, idx }: { news: MarketNews; idx: number }) => (
    <div
      className="bg-white rounded-xl border border-[#E8ECEF] p-6 hover-lift transition-all duration-300 animate-slide-up"
      style={{ animationDelay: `${idx * 0.1}s` }}
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="px-3 py-1 bg-[#F4F8F5] text-[#1F2933] rounded-full text-xs font-semibold">{news.crop}</span>
            <div
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-semibold ${
                news.trend === 'up'
                  ? 'bg-green-100 text-[#1E7F43]'
                  : news.trend === 'down'
                    ? 'bg-red-100 text-[#DC2626]'
                    : 'bg-yellow-100 text-yellow-700'
              }`}
            >
              {news.trend === 'up' ? <TrendingUp size={14} /> : news.trend === 'down' ? '📉' : '➡️'}
              {news.trendPercent}
            </div>
          </div>
          <h3 className="text-lg font-bold text-[#1F2933] mb-2">{news.title}</h3>
        </div>
      </div>

      <p className="text-[#8B95A5] text-sm mb-4">{news.content}</p>

      <div className="bg-[#F4F8F5] rounded-lg p-4 mb-4">
        <p className="text-xs text-[#8B95A5] mb-1">Current Market Rate</p>
        <p className="text-2xl font-bold text-[#1E7F43]">{news.currentRate}</p>
      </div>

      <div className="flex items-center justify-between pt-4 border-t border-[#E8ECEF] text-xs text-[#8B95A5]">
        <span>{news.date}</span>
        <span className="font-semibold">{news.source}</span>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="farmer" userName="Harjeet" />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">Schemes & Market News</h1>
          <p className="text-[#8B95A5]">Government schemes for farmers and live market updates</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8 border-b border-[#E8ECEF] animate-slide-up">
          {[
            { id: 'schemes', label: 'Government Schemes', icon: BookOpen },
            { id: 'news', label: 'Market News & Rates', icon: Zap },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 font-semibold transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'text-[#1E7F43] border-b-2 border-[#1E7F43]'
                    : 'text-[#8B95A5] hover:text-[#1F2933]'
                }`}
              >
                <Icon size={20} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Schemes Tab */}
        {activeTab === 'schemes' && (
          <div className="space-y-6 animate-fade-in">
            {schemes.map((scheme, idx) => (
              <SchemeCard key={scheme.id} scheme={scheme} idx={idx} />
            ))}
          </div>
        )}

        {/* Market News Tab */}
        {activeTab === 'news' && (
          <div className="space-y-6 animate-fade-in">
            {/* Market Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              {[
                { crop: 'Wheat', rate: '₹2,450', change: '+8.2%', positive: true },
                { crop: 'Rice', rate: '₹5,200', change: '+0.5%', positive: true },
                { crop: 'Cotton', rate: '₹6,100', change: '+5.3%', positive: true },
                { crop: 'Maize', rate: '₹2,000', change: '+5.0%', positive: true },
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-xl border border-[#E8ECEF] p-4 hover-glow transition-all duration-300 animate-slide-up"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <p className="text-[#8B95A5] text-sm font-semibold mb-2">{item.crop}</p>
                  <p className="text-2xl font-bold text-[#1F2933] mb-2">{item.rate}</p>
                  <p className={`text-sm font-bold ${item.positive ? 'text-[#1E7F43]' : 'text-[#DC2626]'}`}>
                    {item.positive ? '📈' : '📉'} {item.change}
                  </p>
                </div>
              ))}
            </div>

            {/* News Articles */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {marketNews.map((news, idx) => (
                <NewsCard key={news.id} news={news} idx={idx} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
