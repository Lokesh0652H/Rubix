'use client';

import { useState } from 'react';
import Navbar from '@/components/navbar';
import { ArrowLeft, Save, Edit2, Camera, X } from 'lucide-react';
import Link from 'next/link';

export default function FarmerProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: 'Harjeet Singh',
    phone: '+91 98765 43210',
    email: 'harjeet@farm.com',
    aadharNumber: '****-****-1234',
    state: 'Punjab',
    district: 'Ludhiana',
    village: 'Raipur Kalan',
    farmSize: '2.5 acres',
    crops: 'Wheat, Rice, Cotton',
    bankName: 'HDFC Bank',
    accountNumber: '****-****-6789',
    ifscCode: 'HDFC0001234',
  });

  const [editForm, setEditForm] = useState(formData);

  const handleEdit = () => {
    setIsEditing(true);
    setEditForm(formData);
  };

  const handleSave = () => {
    setFormData(editForm);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="farmer" userName="Harjeet" />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 animate-fade-in">
          <div className="flex items-center gap-4">
            <Link href="/dashboard/farmer">
              <button className="p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow">
                <ArrowLeft size={20} className="text-[#1E7F43]" />
              </button>
            </Link>
            <h1 className="text-3xl font-bold text-[#1F2933]">My Profile</h1>
          </div>
          {!isEditing && (
            <button
              onClick={handleEdit}
              className="flex items-center gap-2 px-4 py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300"
            >
              <Edit2 size={16} />
              Edit Profile
            </button>
          )}
        </div>

        {/* Profile Card */}
        <div className="bg-white rounded-2xl border border-[#E8ECEF] overflow-hidden animate-slide-up">
          {/* Cover & Avatar */}
          <div className="h-32 bg-gradient-to-r from-[#1E7F43] to-[#6BCF9B] relative">
            <div className="absolute -bottom-12 left-8">
              <div className="w-24 h-24 rounded-full border-4 border-white bg-[#A7E3C1] flex items-center justify-center text-3xl hover:shadow-lg transition-all duration-300">
                HS
              </div>
            </div>
            {!isEditing && (
              <button className="absolute top-4 right-4 p-2 bg-white/20 hover:bg-white/30 rounded-full transition-all duration-300">
                <Camera size={20} className="text-white" />
              </button>
            )}
          </div>

          {/* Content */}
          <div className="p-8 pt-16">
            {isEditing ? (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-[#1F2933] mb-2">Full Name</label>
                    <input
                      type="text"
                      name="name"
                      value={editForm.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-[#1F2933] mb-2">Email</label>
                    <input
                      type="email"
                      name="email"
                      value={editForm.email}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-[#1F2933] mb-2">State</label>
                    <input
                      type="text"
                      name="state"
                      value={editForm.state}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-[#1F2933] mb-2">District</label>
                    <input
                      type="text"
                      name="district"
                      value={editForm.district}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-[#1F2933] mb-2">Farm Size</label>
                    <input
                      type="text"
                      name="farmSize"
                      value={editForm.farmSize}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-[#1F2933] mb-2">Crops</label>
                    <input
                      type="text"
                      name="crops"
                      value={editForm.crops}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-[#1F2933] mb-4">Bank Details</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-[#1F2933] mb-2">Bank Name</label>
                      <input
                        type="text"
                        name="bankName"
                        value={editForm.bankName}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#1F2933] mb-2">Account Number</label>
                      <input
                        type="text"
                        name="accountNumber"
                        value={editForm.accountNumber}
                        onChange={handleInputChange}
                        className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 justify-end pt-6">
                  <button
                    onClick={handleCancel}
                    className="px-6 py-2 border border-[#1E7F43] text-[#1E7F43] rounded-lg font-semibold hover:bg-[#F4F8F5] transition-all duration-300"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-2 px-6 py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300"
                  >
                    <Save size={16} />
                    Save Changes
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-8">
                <div>
                  <h2 className="text-2xl font-bold text-[#1F2933] mb-4">{formData.name}</h2>
                  <div className="space-y-2">
                    <p className="text-[#8B95A5]"><span className="font-semibold text-[#1F2933]">Phone:</span> {formData.phone}</p>
                    <p className="text-[#8B95A5]"><span className="font-semibold text-[#1F2933]">Email:</span> {formData.email}</p>
                  </div>
                </div>

                <div className="border-t border-[#E8ECEF] pt-6">
                  <h3 className="text-lg font-bold text-[#1F2933] mb-4">Farm Information</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">State</p>
                      <p className="font-semibold text-[#1F2933]">{formData.state}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">District</p>
                      <p className="font-semibold text-[#1F2933]">{formData.district}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">Village</p>
                      <p className="font-semibold text-[#1F2933]">{formData.village}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">Farm Size</p>
                      <p className="font-semibold text-[#1F2933]">{formData.farmSize}</p>
                    </div>
                    <div className="md:col-span-2">
                      <p className="text-sm text-[#8B95A5] mb-1">Crops Grown</p>
                      <p className="font-semibold text-[#1F2933]">{formData.crops}</p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-[#E8ECEF] pt-6">
                  <h3 className="text-lg font-bold text-[#1F2933] mb-4">Bank Account Details</h3>
                  <div className="space-y-3 p-4 bg-[#F4F8F5] rounded-lg">
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">Bank Name</p>
                      <p className="font-semibold text-[#1F2933]">{formData.bankName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">Account Number</p>
                      <p className="font-semibold text-[#1F2933]">{formData.accountNumber}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#8B95A5] mb-1">IFSC Code</p>
                      <p className="font-semibold text-[#1F2933]">{formData.ifscCode}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
