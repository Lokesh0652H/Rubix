'use client';

import { useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Navbar from '@/components/navbar';
import { Search, Filter, MapPin, Star, TrendingUp, Clock, User } from 'lucide-react';
import Loading from './loading'; // Import the loading component

interface Farmer {
  id: string;
  name: string;
  location: string;
  rating: number;
  reviews: number;
  crops: string[];
  availableCrops: Array<{
    name: string;
    quantity: string;
    harvestDate: string;
    pricePerUnit: number;
  }>;
  verified: boolean;
  yearsExperience: number;
}

export default function BuyerMarketplace() {
  const searchParams = useSearchParams(); // Use useSearchParams
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCrop, setSelectedCrop] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All');

  const farmers: Farmer[] = [
    {
      id: '1',
      name: 'Harjeet Singh Farm',
      location: 'Punjab',
      rating: 4.8,
      reviews: 156,
      crops: ['Wheat', 'Rice', 'Cotton'],
      yearsExperience: 12,
      verified: true,
      availableCrops: [
        { name: 'Wheat (HD2967)', quantity: '500 kg', harvestDate: '2026-02-15', pricePerUnit: 2450 },
        { name: 'Rice (Basmati)', quantity: '1000 kg', harvestDate: '2026-01-20', pricePerUnit: 5200 },
      ],
    },
    {
      id: '2',
      name: 'Rajesh Kumar Farm',
      location: 'Haryana',
      rating: 4.6,
      reviews: 128,
      crops: ['Corn', 'Sugarcane'],
      yearsExperience: 8,
      verified: true,
      availableCrops: [
        { name: 'Corn (Hybrid)', quantity: '800 kg', harvestDate: '2026-02-28', pricePerUnit: 2000 },
      ],
    },
    {
      id: '3',
      name: 'Green Valley Farm',
      location: 'Gujarat',
      rating: 4.5,
      reviews: 94,
      crops: ['Cotton', 'Groundnut'],
      yearsExperience: 10,
      verified: true,
      availableCrops: [
        { name: 'Cotton (MCU5)', quantity: '750 kg', harvestDate: '2026-03-10', pricePerUnit: 6100 },
      ],
    },
  ];

  const filteredFarmers = farmers.filter((farmer) => {
    const matchesSearch = farmer.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCrop = selectedCrop === 'All' || farmer.crops.includes(selectedCrop);
    const matchesLocation = selectedLocation === 'All' || farmer.location === selectedLocation;
    return matchesSearch && matchesCrop && matchesLocation;
  });

  const cropOptions = ['All', 'Wheat', 'Rice', 'Cotton', 'Corn', 'Sugarcane'];
  const locationOptions = ['All', 'Punjab', 'Haryana', 'Gujarat', 'Rajasthan'];

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="buyer" userName="Priya" />

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">Browse Verified Farmers</h1>
          <p className="text-[#8B95A5]">Find quality crops from trusted farmers in your region</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl border border-[#E8ECEF] p-6 mb-8 animate-slide-down">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-3.5 text-[#8B95A5]" size={20} />
              <input
                type="text"
                placeholder="Search farmers by name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
              />
            </div>

            {/* Filter Button */}
            <button className="px-4 py-3 border border-[#E8ECEF] rounded-lg hover:bg-[#F4F8F5] transition-all duration-300 flex items-center gap-2 text-[#1F2933] font-medium">
              <Filter size={20} />
              Filters
            </button>
          </div>

          {/* Filter Dropdowns */}
          <div className="grid md:grid-cols-2 gap-4">
            <select
              value={selectedCrop}
              onChange={(e) => setSelectedCrop(e.target.value)}
              className="px-4 py-3 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
            >
              {cropOptions.map((crop) => (
                <option key={crop} value={crop}>
                  Crop: {crop}
                </option>
              ))}
            </select>

            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              className="px-4 py-3 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43] transition-colors"
            >
              {locationOptions.map((location) => (
                <option key={location} value={location}>
                  Location: {location}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Farmers Grid */}
        <div className="grid md:grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredFarmers.map((farmer, idx) => (
            <div
              key={farmer.id}
              className="bg-white rounded-xl border border-[#E8ECEF] hover:border-[#1E7F43] transition-all duration-300 overflow-hidden animate-slide-up hover-lift"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              {/* Farmer Header */}
              <div className="p-6 border-b border-[#E8ECEF]">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <h2 className="text-xl font-bold text-[#1F2933]">{farmer.name}</h2>
                      {farmer.verified && <span className="px-2 py-1 bg-[#1E7F43]/10 text-[#1E7F43] text-xs font-bold rounded">✓ Verified</span>}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-[#8B95A5]">
                      <div className="flex items-center gap-1">
                        <MapPin size={16} />
                        {farmer.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock size={16} />
                        {farmer.yearsExperience} years
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-1 justify-end mb-1">
                      <Star size={16} className="text-[#F4B400] fill-[#F4B400]" />
                      <span className="font-bold text-[#1F2933]">{farmer.rating}</span>
                    </div>
                    <p className="text-xs text-[#8B95A5]">{farmer.reviews} reviews</p>
                  </div>
                </div>

                {/* Crops Offered */}
                <div className="flex gap-2 flex-wrap">
                  {farmer.crops.map((crop, idx) => (
                    <span key={idx} className="px-3 py-1 bg-[#A7E3C1]/20 text-[#1E7F43] text-xs font-semibold rounded-full">
                      {crop}
                    </span>
                  ))}
                </div>
              </div>

              {/* Available Crops */}
              <div className="p-6">
                <h3 className="font-bold text-[#1F2933] mb-4">Available Crops</h3>
                <div className="space-y-3">
                  {farmer.availableCrops.map((crop, idx) => (
                    <div key={idx} className="p-4 bg-[#F4F8F5] rounded-lg border border-[#E8ECEF] hover:border-[#1E7F43] transition-all duration-300">
                      <div className="flex justify-between items-start mb-2">
                        <p className="font-semibold text-[#1F2933]">{crop.name}</p>
                        <p className="text-lg font-bold text-[#1E7F43]">₹{crop.pricePerUnit}/unit</p>
                      </div>
                      <div className="flex gap-4 text-sm text-[#8B95A5]">
                        <span>📦 {crop.quantity}</span>
                        <span>📅 Harvest: {crop.harvestDate}</span>
                      </div>
                      <button className="w-full mt-3 py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300">
                        Place Bid
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-6 border-t border-[#E8ECEF] bg-[#F4F8F5] flex gap-4">
                <button className="flex-1 py-2 border border-[#1E7F43] text-[#1E7F43] rounded-lg font-semibold hover:bg-[#1E7F43]/10 transition-all duration-300">
                  View Profile
                </button>
                <button className="flex-1 py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300">
                  Connect
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredFarmers.length === 0 && (
          <div className="text-center py-16 animate-fade-in">
            <p className="text-[#8B95A5] text-lg">No farmers found matching your criteria</p>
          </div>
        )}
      </main>
    </div>
  );
}

// loading.tsx
export default function Loading() {
  return null;
}
