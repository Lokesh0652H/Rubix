'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Navbar from '@/components/navbar';
import { Plus, TrendingUp, DollarSign, ShoppingCart, FileText, ArrowUpRight, AlertCircle } from 'lucide-react';

export default function FarmerDashboard() {
  const [earnings, setEarnings] = useState(0);
  const [contracts, setContracts] = useState(0);
  const [listings, setListings] = useState(0);

  // Animate counters
  useEffect(() => {
    const interval = setInterval(() => {
      setEarnings((prev) => (prev < 3385000 ? prev + 50000 : prev));
      setContracts((prev) => (prev < 10 ? prev + 1 : prev));
      setListings((prev) => (prev < 8 ? prev + 1 : prev));
    }, 100);
    return () => clearInterval(interval);
  }, []);

  const statsCards = [
    { title: 'Total Earnings', value: `₹${(earnings / 100000).toFixed(2)}L`, icon: DollarSign, color: 'text-[#1E7F43]', delay: 0 },
    { title: 'Active Contracts', value: contracts, icon: FileText, color: 'text-[#6BCF9B]', delay: 0.1 },
    { title: 'Active Listings', value: listings, icon: ShoppingCart, color: 'text-[#A7E3C1]', delay: 0.2 },
  ];

  const recentActivities = [
    { action: 'Contract Accepted', crop: 'Wheat (500kg)', buyer: 'National Grain Corp', status: 'completed', time: '2 hours ago' },
    { action: 'New Bid Received', crop: 'Maize (200kg)', buyer: 'XYZ Dealers', status: 'pending', time: '4 hours ago', bidAmount: '₹28,500' },
    { action: 'Payment Received', crop: 'Rice (1000kg)', buyer: 'Tata Foods', status: 'completed', time: '1 day ago', amount: '₹45,600' },
    { action: 'Bid Placed', crop: 'Cotton (750kg)', buyer: 'Textile Industries', status: 'pending', time: '2 days ago', bidAmount: '₹52,000' },
  ];

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="farmer" userName="Harjeet" />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">Dashboard</h1>
          <p className="text-[#8B95A5]">Welcome back! Here's your farming overview</p>
        </div>

        {/* Stats Cards - 3 Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {statsCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-xl border border-[#E8ECEF] p-6 hover-lift transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${card.delay}s` }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-[#8B95A5] text-sm font-medium mb-2">{card.title}</p>
                    <p className={`text-3xl font-bold ${card.color}`}>{card.value}</p>
                  </div>
                  <div className="p-3 bg-[#F4F8F5] rounded-lg">
                    <Icon size={24} className={card.color} />
                  </div>
                </div>
                <div className="flex items-center gap-2 text-xs text-[#1E7F43]">
                  <ArrowUpRight size={14} />
                  <span>12% increase this month</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Link href="/marketplace">
            <div className="bg-[#1E7F43] text-white rounded-xl p-6 hover-lift transition-all duration-300 cursor-pointer animate-slide-up group">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/20 rounded-lg group-hover:bg-white/30 transition-all duration-300">
                  <Plus size={24} />
                </div>
                <div>
                  <p className="font-bold">List Crop</p>
                  <p className="text-sm text-white/80">Create new listing</p>
                </div>
              </div>
            </div>
          </Link>
          <Link href="/my-contracts">
            <div className="bg-[#6BCF9B] text-white rounded-xl p-6 hover-lift transition-all duration-300 cursor-pointer animate-slide-up group" style={{ animationDelay: '0.1s' }}>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/20 rounded-lg group-hover:bg-white/30 transition-all duration-300">
                  <FileText size={24} />
                </div>
                <div>
                  <p className="font-bold">My Contracts</p>
                  <p className="text-sm text-white/80">View all contracts</p>
                </div>
              </div>
            </div>
          </Link>
          <Link href="/analytics">
            <div className="bg-[#A7E3C1] text-[#1F2933] rounded-xl p-6 hover-lift transition-all duration-300 cursor-pointer animate-slide-up group" style={{ animationDelay: '0.2s' }}>
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white/20 rounded-lg group-hover:bg-white/30 transition-all duration-300">
                  <TrendingUp size={24} />
                </div>
                <div>
                  <p className="font-bold">Analytics</p>
                  <p className="text-sm text-[#1F2933]/80">View insights</p>
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* Recent Activities */}
        <div className="bg-white rounded-xl border border-[#E8ECEF] p-6 animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-[#1F2933]">Recent Activities</h2>
            <Link href="/my-contracts" className="text-sm text-[#1E7F43] font-semibold hover:underline">View all</Link>
          </div>
          
          <div className="space-y-3">
            {recentActivities.map((activity, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-4 border border-[#E8ECEF] rounded-lg hover:border-[#1E7F43] transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <div className="flex items-center gap-4 flex-1">
                  <div className={`w-2 h-2 rounded-full ${activity.status === 'completed' ? 'bg-[#1E7F43]' : 'bg-[#F4B400]'}`} />
                  <div>
                    <p className="font-semibold text-[#1F2933] text-sm">{activity.action}</p>
                    <p className="text-xs text-[#8B95A5]">
                      {activity.crop} • {activity.buyer}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  {activity.bidAmount && <p className="text-sm font-bold text-[#1E7F43]">{activity.bidAmount}</p>}
                  {activity.amount && <p className="text-sm font-bold text-[#1E7F43]">{activity.amount}</p>}
                  <p className="text-xs text-[#8B95A5]">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
