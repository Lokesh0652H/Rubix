'use client';

import { useState } from 'react';
import Navbar from '@/components/navbar';
import { TrendingUp, X, Check, Clock } from 'lucide-react';

interface Bid {
  id: string;
  cropName: string;
  farmer: string;
  quantity: string;
  yourBid: number;
  highestBid: number;
  deadline: string;
  status: 'winning' | 'outbid' | 'pending' | 'accepted';
  placedAt: string;
}

export default function BuyerBids() {
  const [bids, setBids] = useState<Bid[]>([
    {
      id: '1',
      cropName: 'Wheat (HD2967)',
      farmer: 'Harjeet Singh Farm',
      quantity: '500 kg',
      yourBid: 2450,
      highestBid: 2450,
      deadline: '2026-02-10',
      status: 'winning',
      placedAt: '2 hours ago',
    },
    {
      id: '2',
      cropName: 'Rice (Basmati)',
      farmer: 'Rajesh Kumar Farm',
      quantity: '1000 kg',
      yourBid: 5100,
      highestBid: 5200,
      deadline: '2026-01-18',
      status: 'outbid',
      placedAt: '1 day ago',
    },
    {
      id: '3',
      cropName: 'Cotton (MCU5)',
      farmer: 'Green Valley Farm',
      quantity: '750 kg',
      yourBid: 6000,
      highestBid: 6100,
      deadline: '2026-03-08',
      status: 'pending',
      placedAt: '3 days ago',
    },
  ]);

  const [selectedBid, setSelectedBid] = useState<string | null>(null);
  const [bidAmount, setBidAmount] = useState('');

  const handlePlaceBid = (bidId: string, currentBid: number) => {
    const newBidAmount = parseFloat(bidAmount);
    if (newBidAmount > currentBid) {
      setBids((prev) =>
        prev.map((bid) =>
          bid.id === bidId
            ? { ...bid, yourBid: newBidAmount, status: 'winning', highestBid: newBidAmount }
            : bid
        )
      );
      setSelectedBid(null);
      setBidAmount('');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'winning':
        return 'bg-[#1E7F43]/10 text-[#1E7F43] border-[#1E7F43]';
      case 'accepted':
        return 'bg-[#6BCF9B]/10 text-[#1E7F43] border-[#6BCF9B]';
      case 'outbid':
        return 'bg-red-50 text-red-600 border-red-200';
      default:
        return 'bg-yellow-50 text-yellow-600 border-yellow-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'winning':
        return <TrendingUp size={16} />;
      case 'accepted':
        return <Check size={16} />;
      case 'outbid':
        return <X size={16} />;
      default:
        return <Clock size={16} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="buyer" userName="Priya" />

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">My Active Bids</h1>
          <p className="text-[#8B95A5]">Track and manage all your current bids</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-lg border border-[#E8ECEF] p-6 animate-slide-up">
            <p className="text-[#8B95A5] text-sm mb-2">Total Active Bids</p>
            <p className="text-3xl font-bold text-[#1E7F43]">{bids.length}</p>
          </div>
          <div className="bg-white rounded-lg border border-[#E8ECEF] p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <p className="text-[#8B95A5] text-sm mb-2">Winning</p>
            <p className="text-3xl font-bold text-[#1E7F43]">{bids.filter((b) => b.status === 'winning').length}</p>
          </div>
          <div className="bg-white rounded-lg border border-[#E8ECEF] p-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <p className="text-[#8B95A5] text-sm mb-2">Total Bid Value</p>
            <p className="text-3xl font-bold text-[#1E7F43]">₹{bids.reduce((sum, b) => sum + b.yourBid, 0).toLocaleString()}</p>
          </div>
        </div>

        {/* Bids List */}
        <div className="space-y-4">
          {bids.map((bid, idx) => (
            <div
              key={bid.id}
              className="bg-white rounded-lg border border-[#E8ECEF] p-6 hover:border-[#1E7F43] transition-all duration-300 animate-slide-up hover-lift"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              <div className="grid md:grid-cols-2 gap-6">
                {/* Left Side - Bid Details */}
                <div>
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-[#1F2933] mb-1">{bid.cropName}</h3>
                      <p className="text-sm text-[#8B95A5]">{bid.farmer}</p>
                    </div>
                    <div className={`px-3 py-1 rounded-full border text-xs font-bold flex items-center gap-1 ${getStatusColor(bid.status)}`}>
                      {getStatusIcon(bid.status)}
                      {bid.status.charAt(0).toUpperCase() + bid.status.slice(1)}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-[#8B95A5] text-xs mb-1">Quantity</p>
                      <p className="font-semibold text-[#1F2933]">{bid.quantity}</p>
                    </div>
                    <div>
                      <p className="text-[#8B95A5] text-xs mb-1">Deadline</p>
                      <p className="font-semibold text-[#1F2933]">{bid.deadline}</p>
                    </div>
                  </div>

                  <p className="text-xs text-[#8B95A5]">Bid placed {bid.placedAt}</p>
                </div>

                {/* Right Side - Bid Pricing */}
                <div className="border-l border-[#E8ECEF] pl-6">
                  <div className="mb-6">
                    <div className="mb-4">
                      <p className="text-[#8B95A5] text-sm mb-1">Your Bid</p>
                      <p className="text-3xl font-bold text-[#1E7F43]">₹{bid.yourBid}</p>
                    </div>
                    <div className="mb-4">
                      <p className="text-[#8B95A5] text-sm mb-1">Highest Bid</p>
                      <p className="text-2xl font-bold text-[#1F2933]">₹{bid.highestBid}</p>
                    </div>
                  </div>

                  {selectedBid === bid.id ? (
                    <div className="space-y-3">
                      <input
                        type="number"
                        value={bidAmount}
                        onChange={(e) => setBidAmount(e.target.value)}
                        placeholder={`Enter amount > ₹${bid.highestBid}`}
                        className="w-full px-3 py-2 border border-[#E8ECEF] rounded-lg focus:outline-none focus:border-[#1E7F43]"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => handlePlaceBid(bid.id, bid.highestBid)}
                          className="flex-1 py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all"
                        >
                          Place Bid
                        </button>
                        <button
                          onClick={() => {
                            setSelectedBid(null);
                            setBidAmount('');
                          }}
                          className="flex-1 py-2 border border-[#E8ECEF] rounded-lg font-semibold hover:bg-[#F4F8F5] transition-all"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => setSelectedBid(bid.id)}
                      className="w-full py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all"
                    >
                      Revise Bid
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
