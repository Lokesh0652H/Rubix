'use client';

import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { CheckCircle, Home } from 'lucide-react';
import { Suspense } from 'react';
import Loading from './loading';

function SuccessContent() {
  const searchParams = useSearchParams();
  const title = searchParams.get('title') || 'Success';
  const message = searchParams.get('message') || 'Your action has been completed successfully.';
  const redirect = searchParams.get('redirect') || '/';

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center px-4">
      <div className="text-center max-w-md animate-fade-in">
        <div className="mb-6 flex justify-center">
          <div className="p-4 bg-[#1E7F43]/10 rounded-full animate-scale-in">
            <CheckCircle size={64} className="text-[#1E7F43]" />
          </div>
        </div>
        
        <h1 className="text-4xl font-bold text-[#1F2933] mb-4">{title}</h1>
        <p className="text-[#8B95A5] mb-8">{message}</p>
        
        <Link href={redirect}>
          <button className="flex items-center justify-center gap-2 px-8 py-3 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300 w-full">
            <Home size={18} />
            Back to Home
          </button>
        </Link>
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={<Loading />}>
      <SuccessContent />
    </Suspense>
  );
}
