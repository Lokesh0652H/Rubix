'use client';

import { useState } from 'react';
import Navbar from '@/components/navbar';
import { ArrowLeft, MessageSquare, Phone, Mail, Search, ChevronDown } from 'lucide-react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Suspense } from 'react';
import Loading from './loading';

export default function Help() {
  const [expandedFaq, setExpandedFaq] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const searchParams = useSearchParams();

  const faqs = [
    {
      id: 1,
      category: 'Getting Started',
      question: 'How do I create an account?',
      answer: 'Visit the landing page and select whether you are a Farmer or Buyer. Fill in your phone number, verify the OTP, and complete your profile setup. You will be guided through each step.'
    },
    {
      id: 2,
      category: 'Getting Started',
      question: 'What documents do I need as a farmer?',
      answer: 'Farmers need a valid government ID (Aadhaar, PAN, or Voter ID), a selfie for verification, and bank account details for payment transfers.'
    },
    {
      id: 3,
      category: 'Listings & Bids',
      question: 'How do I list my crops?',
      answer: 'Go to Marketplace > List Crop. Fill in crop details including type, quantity, quality, location, and minimum price. Your listing will be live immediately.'
    },
    {
      id: 4,
      category: 'Listings & Bids',
      question: 'How do I place a bid as a buyer?',
      answer: 'Browse available crops in the Marketplace, click on a listing, and place your bid amount. The farmer can accept or counter your bid.'
    },
    {
      id: 5,
      category: 'Contracts',
      question: 'What happens after a contract is signed?',
      answer: 'Once a contract is signed, both parties commit to the terms. Payment is held in escrow until the crop delivery is confirmed. You can track everything in the Contracts section.'
    },
    {
      id: 6,
      category: 'Payments',
      question: 'How are payments processed?',
      answer: 'Payments are secure and processed through the platform. The amount is held in escrow until delivery is confirmed, then transferred to your registered bank account within 24 hours.'
    },
    {
      id: 7,
      category: 'Support',
      question: 'What should I do if I have a dispute?',
      answer: 'Contact our support team immediately. Our team will review the contract terms, communicate with both parties, and resolve disputes fairly based on the evidence provided.'
    },
    {
      id: 8,
      category: 'Support',
      question: 'How can I contact customer support?',
      answer: 'You can reach us via phone, email, or the in-app chat. Our support team is available 24/7 to help you with any issues.'
    },
  ];

  const filteredFaqs = faqs.filter(faq =>
    faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const contactMethods = [
    { icon: Phone, title: 'Phone Support', value: '+91 1234-567-890', description: '24/7 Available' },
    { icon: Mail, title: 'Email Support', value: 'support@agrisetu.com', description: 'Response within 2 hours' },
    { icon: MessageSquare, title: 'Live Chat', value: 'In-app chat', description: 'Real-time support' },
  ];

  return (
    <div className="min-h-screen bg-[#F4F8F5]">
      <Navbar userType="farmer" userName="Harjeet" />
      
      <main className="max-w-4xl mx-auto px-4 py-8 pt-24">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-fade-in">
          <Link href="/dashboard/farmer">
            <button className="p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow">
              <ArrowLeft size={20} className="text-[#1E7F43]" />
            </button>
          </Link>
          <h1 className="text-3xl font-bold text-[#1F2933]">Help & Support</h1>
        </div>

        {/* Quick Contact */}
        <div className="grid md:grid-cols-3 gap-4 mb-12">
          {contactMethods.map((method, idx) => {
            const Icon = method.icon;
            return (
              <div
                key={idx}
                className="p-6 bg-white rounded-xl border border-[#E8ECEF] hover:border-[#1E7F43] transition-all duration-300 hover-lift animate-slide-up"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <Icon size={32} className="text-[#1E7F43] mb-3" />
                <h3 className="font-bold text-[#1F2933] mb-1">{method.title}</h3>
                <p className="text-sm font-semibold text-[#1E7F43] mb-2">{method.value}</p>
                <p className="text-xs text-[#8B95A5]">{method.description}</p>
              </div>
            );
          })}
        </div>

        {/* Search FAQs */}
        <div className="mb-8 animate-slide-up">
          <div className="relative">
            <Search size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[#8B95A5]" />
            <input
              type="text"
              placeholder="Search help articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border border-[#E8ECEF] rounded-xl focus:outline-none focus:border-[#1E7F43] transition-colors"
            />
          </div>
        </div>

        {/* FAQs */}
        <div className="space-y-3">
          <h2 className="text-2xl font-bold text-[#1F2933] mb-6">Frequently Asked Questions</h2>
          
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map((faq, idx) => (
              <div
                key={faq.id}
                className="bg-white rounded-xl border border-[#E8ECEF] overflow-hidden hover:border-[#1E7F43] transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <button
                  onClick={() => setExpandedFaq(expandedFaq === faq.id ? null : faq.id)}
                  className="w-full p-4 flex items-center justify-between hover:bg-[#F4F8F5] transition-colors duration-300 text-left"
                >
                  <div>
                    <span className="inline-block px-2 py-1 text-xs font-semibold text-[#1E7F43] bg-[#1E7F43]/10 rounded mb-2 mr-2">
                      {faq.category}
                    </span>
                    <p className="font-bold text-[#1F2933]">{faq.question}</p>
                  </div>
                  <ChevronDown
                    size={20}
                    className={`text-[#8B95A5] flex-shrink-0 transition-transform duration-300 ${
                      expandedFaq === faq.id ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {expandedFaq === faq.id && (
                  <div className="px-4 py-4 border-t border-[#E8ECEF] bg-[#F4F8F5] animate-slide-down">
                    <p className="text-[#8B95A5]">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-12 bg-white rounded-xl border border-[#E8ECEF]">
              <p className="text-[#8B95A5] mb-2">No results found for "{searchQuery}"</p>
              <p className="text-sm text-[#8B95A5]">Try a different search term or contact our support team</p>
            </div>
          )}
        </div>

        {/* Additional Resources */}
        <div className="mt-12 p-6 bg-white rounded-xl border border-[#E8ECEF] animate-fade-in">
          <h3 className="text-lg font-bold text-[#1F2933] mb-4">Need More Help?</h3>
          <p className="text-[#8B95A5] mb-4">
            If you couldn't find the answer, our support team is here to help. Reach out through any of the contact methods above.
          </p>
          <a
            href="mailto:support@agrisetu.com"
            className="inline-block px-6 py-2 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300"
          >
            Contact Support
          </a>
        </div>
      </main>
    </div>
  );
}

export function generateStaticParams() {
  return [{ lang: 'en' }];
}

export default function HelpPage() {
  return (
    <Suspense fallback={<Loading />}>
      <Help />
    </Suspense>
  );
}
