'use client';

import React from "react"

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, Lock, User } from 'lucide-react';

export default function AdminLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      setIsSubmitting(true);
      // Simulate login
      setTimeout(() => {
        window.location.href = '/admin/dashboard';
      }, 600);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center p-4">
      {/* Back Button */}
      <Link
        href="/"
        className="fixed top-6 left-6 p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow"
      >
        <ArrowLeft size={20} className="text-[#1E7F43]" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        {/* Logo/Header */}
        <div className="text-center mb-12 animate-slide-down">
          <div className="w-16 h-16 mx-auto mb-4 bg-[#1E7F43] rounded-full flex items-center justify-center text-white animate-float">
            <Lock size={32} />
          </div>
          <h1 className="text-3xl font-bold text-[#1E7F43] mb-2">ArgiSetu</h1>
          <p className="text-[#8B95A5]">Administrator Portal</p>
        </div>

        {/* Login Card */}
        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 shadow-sm hover-glow animate-scale-in">
          <h2 className="text-2xl font-bold text-[#1F2933] mb-2">Admin Access</h2>
          <p className="text-[#8B95A5] text-sm mb-8">
            Government-authorized administrators only
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email Input */}
            <div className="animate-slide-up">
              <label className="block text-sm font-semibold text-[#1F2933] mb-2">
                <User size={16} className="inline mr-2 text-[#1E7F43]" />
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@agrisetu.gov"
                className="w-full px-4 py-3 border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300 placeholder:text-[#8B95A5]"
              />
            </div>

            {/* Password Input */}
            <div className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <label className="block text-sm font-semibold text-[#1F2933] mb-2">
                <Lock size={16} className="inline mr-2 text-[#1E7F43]" />
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter secure password"
                className="w-full px-4 py-3 border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300 placeholder:text-[#8B95A5]"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!email || !password || isSubmitting}
              className={`w-full py-3 px-4 rounded-lg font-semibold button-ripple transition-all duration-300 mt-6 ${
                email && password && !isSubmitting
                  ? 'bg-[#1E7F43] text-white hover:bg-[#165a33] hover:shadow-lg'
                  : 'bg-[#E8ECEF] text-[#8B95A5] cursor-not-allowed'
              }`}
            >
              {isSubmitting ? (
                <span className="inline-flex items-center gap-2">
                  <span className="animate-spin-slow">🔐</span>
                  Authenticating...
                </span>
              ) : (
                'Admin Login'
              )}
            </button>
          </form>

          {/* Security Info */}
          <div className="mt-8 p-4 bg-[#F4F8F5] rounded-lg border border-[#A7E3C1]/30 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <p className="text-xs text-[#1F2933]">
              <span className="font-semibold">🔒 Secure Access:</span> All admin activities are logged and monitored for compliance.
            </p>
          </div>

          {/* Demo Credentials Info */}
          <div className="mt-4 p-3 bg-[#6BCF9B]/10 rounded-lg border border-[#A7E3C1] animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <p className="text-xs text-[#1F2933]">
              <span className="font-semibold">Demo:</span> Any email and password will work for demonstration
            </p>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-[#8B95A5] mt-8">
          © 2024 ArgiSetu - Government of India Digital Agriculture Platform
        </p>
      </div>
    </div>
  );
}
