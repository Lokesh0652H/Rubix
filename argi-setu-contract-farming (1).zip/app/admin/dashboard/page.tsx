'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { LogOut, Users, FileText, AlertCircle, BarChart3, TrendingUp, CheckCircle, PieChart, Eye, MessageSquare } from 'lucide-react';

export default function AdminDashboard() {
  const [totalFarmers, setTotalFarmers] = useState(0);
  const [totalBuyers, setTotalBuyers] = useState(0);
  const [totalContracts, setTotalContracts] = useState(0);
  const [disputes, setDisputes] = useState(0);

  // Animate counters
  useEffect(() => {
    const interval = setInterval(() => {
      setTotalFarmers((prev) => (prev < 2847 ? prev + 95 : prev));
      setTotalBuyers((prev) => (prev < 432 ? prev + 15 : prev));
      setTotalContracts((prev) => (prev < 5623 ? prev + 188 : prev));
      setDisputes((prev) => (prev < 23 ? prev + 1 : prev));
    }, 80);
    return () => clearInterval(interval);
  }, []);

  const statsCards = [
    { title: 'Total Farmers', value: totalFarmers.toLocaleString(), icon: Users, color: 'text-[#1E7F43]', bg: 'bg-[#1E7F43]/10', delay: 0 },
    { title: 'Total Buyers', value: totalBuyers.toLocaleString(), icon: Users, color: 'text-[#6BCF9B]', bg: 'bg-[#6BCF9B]/10', delay: 0.1 },
    { title: 'Active Contracts', value: totalContracts.toLocaleString(), icon: FileText, color: 'text-[#A7E3C1]', bg: 'bg-[#A7E3C1]/10', delay: 0.2 },
    { title: 'Active Disputes', value: disputes, icon: AlertCircle, color: 'text-red-500', bg: 'bg-red-50', delay: 0.3 },
  ];

  const recentDisputes = [
    { id: 1, farmer: 'Raj Patel', buyer: 'ABC Trading', crop: 'Wheat (500kg)', status: 'pending', severity: 'medium' },
    { id: 2, farmer: 'Kumar Singh', buyer: 'XYZ Dealers', crop: 'Rice (1000kg)', status: 'resolved', severity: 'low' },
    { id: 3, farmer: 'Priya Sharma', buyer: 'Green Ventures', crop: 'Corn (200kg)', status: 'investigating', severity: 'high' },
  ];

  return (
    <div className="min-h-screen bg-[#F4F8F5]">
      {/* Top Navbar */}
      <nav className="bg-white border-b border-[#E8ECEF] sticky top-0 z-40 animate-slide-down">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 text-[#1E7F43] hover:opacity-80 transition-opacity">
              <span className="font-bold text-lg">🛡️ ArgiSetu Admin</span>
            </Link>

            {/* Navigation Links */}
            <div className="hidden md:flex items-center gap-8">
              <Link href="/admin/dashboard" className="text-[#1F2933] font-medium hover:text-[#1E7F43] transition-colors">
                Dashboard
              </Link>
              <Link href="/admin/dashboard" className="text-[#8B95A5] hover:text-[#1E7F43] transition-colors">
                Farmer Management
              </Link>
              <Link href="/admin/dashboard" className="text-[#8B95A5] hover:text-[#1E7F43] transition-colors">
                Buyer Management
              </Link>
              <Link href="/admin/dashboard" className="text-[#8B95A5] hover:text-[#1E7F43] transition-colors">
                Disputes
              </Link>
              <Link href="/admin/dashboard" className="text-[#8B95A5] hover:text-[#1E7F43] transition-colors">
                Market Prices
              </Link>
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-4">
              <Link href="/" className="p-2 hover:bg-red-50 rounded-full transition-all duration-300 hover-glow">
                <LogOut size={20} className="text-red-500" />
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header Section */}
        <div className="mb-12 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">System Overview 📊</h1>
          <p className="text-[#8B95A5]">Real-time monitoring of ArgiSetu platform</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          {statsCards.map((card, idx) => {
            const Icon = card.icon;
            return (
              <div
                key={idx}
                className="bg-white rounded-2xl border border-[#E8ECEF] p-6 hover-lift animate-fade-in"
                style={{ animationDelay: `${card.delay}s` }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="text-[#8B95A5] text-xs font-medium mb-1">{card.title}</p>
                    <p className={`text-3xl font-bold ${card.color}`}>{card.value}</p>
                  </div>
                  <div className={`${card.bg} p-3 rounded-lg`}>
                    <Icon size={20} className={card.color} />
                  </div>
                </div>
                <div className="flex items-center gap-1 text-xs text-[#6BCF9B]">
                  <TrendingUp size={12} />
                  <span>Live updated</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6 mb-12">
          {/* Active Disputes */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-[#E8ECEF] p-8 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <div className="flex items-center gap-2 mb-6">
              <AlertCircle size={24} className="text-red-500" />
              <h2 className="text-2xl font-bold text-[#1F2933]">Active Disputes</h2>
            </div>

            <div className="space-y-4">
              {recentDisputes.map((dispute, idx) => (
                <div
                  key={dispute.id}
                  className="p-4 border border-[#E8ECEF] rounded-lg hover:border-red-300 transition-all duration-300 hover-glow animate-slide-up"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <p className="font-semibold text-[#1F2933]">{dispute.farmer}</p>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          dispute.severity === 'high' ? 'bg-red-100 text-red-700' :
                          dispute.severity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {dispute.severity.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-sm text-[#8B95A5]">
                        {dispute.buyer} • {dispute.crop}
                      </p>
                    </div>
                    <span className={`text-xs font-semibold px-3 py-1 rounded-full ${
                      dispute.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                      dispute.status === 'resolved' ? 'bg-green-100 text-green-700' :
                      'bg-blue-100 text-blue-700'
                    }`}>
                      {dispute.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="space-y-4">
            {/* System Health */}
            <div className="bg-white rounded-2xl border border-[#E8ECEF] p-6 hover-glow animate-fade-in" style={{ animationDelay: '0.3s' }}>
              <h3 className="font-bold text-[#1F2933] mb-4">System Health</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs text-[#8B95A5] mb-1">
                    <span>Server Status</span>
                    <span>99.8%</span>
                  </div>
                  <div className="w-full h-2 bg-[#E8ECEF] rounded-full overflow-hidden">
                    <div className="h-full bg-[#1E7F43] rounded-full" style={{ width: '99.8%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-[#8B95A5] mb-1">
                    <span>Database</span>
                    <span>98.5%</span>
                  </div>
                  <div className="w-full h-2 bg-[#E8ECEF] rounded-full overflow-hidden">
                    <div className="h-full bg-[#6BCF9B] rounded-full" style={{ width: '98.5%' }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-[#8B95A5] mb-1">
                    <span>API Response</span>
                    <span>97.2%</span>
                  </div>
                  <div className="w-full h-2 bg-[#E8ECEF] rounded-full overflow-hidden">
                    <div className="h-full bg-[#A7E3C1] rounded-full" style={{ width: '97.2%' }} />
                  </div>
                </div>
              </div>
            </div>

            {/* Market Updates */}
            <div className="bg-white rounded-2xl border border-[#E8ECEF] p-6 hover-glow animate-fade-in" style={{ animationDelay: '0.4s' }}>
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={20} className="text-[#F4B400]" />
                <h3 className="font-bold text-[#1F2933]">Market Updates</h3>
              </div>
              <div className="space-y-2 text-sm">
                <p className="text-[#8B95A5]">✓ Prices updated: 2m ago</p>
                <p className="text-[#8B95A5]">✓ Contracts verified: 47 today</p>
                <p className="text-[#8B95A5]">✓ Disputes resolved: 12 this week</p>
              </div>
            </div>
          </div>
        </div>

        {/* Audit Trail Preview */}
        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 animate-fade-in" style={{ animationDelay: '0.5s' }}>
          <h2 className="text-2xl font-bold text-[#1F2933] mb-6">Audit Trail (Last 24h)</h2>
          <div className="space-y-3">
            {[
              { action: 'New farmer registered', user: 'System', time: '2 hours ago' },
              { action: 'Contract verified', user: 'Admin User', time: '4 hours ago' },
              { action: 'Dispute escalated', user: 'System', time: '6 hours ago' },
              { action: 'Price index updated', user: 'System', time: '12 hours ago' },
            ].map((log, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between p-3 border-l-4 border-[#1E7F43] bg-[#F4F8F5] rounded animate-slide-up"
                style={{ animationDelay: `${idx * 0.08}s` }}
              >
                <div>
                  <p className="font-semibold text-[#1F2933]">{log.action}</p>
                  <p className="text-xs text-[#8B95A5]">By: {log.user}</p>
                </div>
                <span className="text-xs text-[#8B95A5]">{log.time}</span>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
