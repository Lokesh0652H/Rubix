'use client';

import React from "react"
import Loading from './loading';

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { ArrowLeft, Check } from 'lucide-react';

function BuyerOTPContent() {
  const searchParams = useSearchParams();
  const phone = searchParams.get('phone') || '';
  
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [timer, setTimer] = useState(60);
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (timer > 0) {
      const interval = setTimeout(() => setTimer(timer - 1), 1000);
      return () => clearTimeout(interval);
    }
  }, [timer]);

  const handleOtpChange = (index: number, value: string) => {
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    
    if (value && index < 5) {
      document.getElementById(`otp-${index + 1}`)?.focus();
    }
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    const otpCode = otp.join('');
    if (otpCode.length === 6) {
      setLoading(true);
      setTimeout(() => {
        setVerified(true);
        setTimeout(() => {
          window.location.href = `/auth/buyer/profile?phone=${phone}`;
        }, 1500);
      }, 500);
    }
  };

  const handleResend = () => {
    setTimer(60);
    setOtp(['', '', '', '', '', '']);
  };

  if (verified) {
    return (
      <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center p-4">
        <div className="text-center animate-fade-in">
          <div className="inline-block p-6 bg-[#1E7F43]/10 rounded-full mb-6 animate-scale-in">
            <Check size={48} className="text-[#1E7F43]" />
          </div>
          <h2 className="text-3xl font-bold text-[#1F2933] mb-2">Verified!</h2>
          <p className="text-[#8B95A5]">Setting up your profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F4F8F5] to-[#A7E3C1]/10 flex items-center justify-center p-4">
      <Link
        href="/"
        className="fixed top-6 left-6 p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow"
      >
        <ArrowLeft size={20} className="text-[#1E7F43]" />
      </Link>

      <div className="w-full max-w-md">
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-3xl font-bold text-[#1E7F43] mb-2">ArgiSetu</h1>
          <p className="text-[#8B95A5]">OTP Verification</p>
        </div>

        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 shadow-lg animate-scale-in">
          {/* Progress */}
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4].map((step) => (
              <div
                key={step}
                className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                  step <= 2 ? 'bg-[#1E7F43]' : 'bg-[#E8ECEF]'
                }`}
              />
            ))}
          </div>

          <h2 className="text-2xl font-bold text-[#1F2933] mb-2">Enter Verification Code</h2>
          <p className="text-[#8B95A5] text-sm mb-8">
            We sent a 6-digit code to +91 {phone}
          </p>

          <form onSubmit={handleVerify} className="space-y-6">
            {/* OTP Inputs */}
            <div className="flex gap-3 justify-center">
              {otp.map((digit, index) => (
                <input
                  key={index}
                  id={`otp-${index}`}
                  type="tel"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleOtpChange(index, e.target.value)}
                  className="w-12 h-12 text-center text-lg font-bold border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300"
                />
              ))}
            </div>

            {/* Verify Button */}
            <button
              type="submit"
              disabled={otp.join('').length !== 6 || loading}
              className={`w-full py-3 px-4 rounded-lg font-semibold button-ripple transition-all duration-300 ${
                otp.join('').length === 6 && !loading
                  ? 'bg-[#1E7F43] text-white hover:bg-[#165a33]'
                  : 'bg-[#E8ECEF] text-[#8B95A5] cursor-not-allowed'
              }`}
            >
              {loading ? 'Verifying...' : 'Verify Code'}
            </button>

            {/* Resend Code */}
            <div className="text-center">
              {timer > 0 ? (
                <p className="text-sm text-[#8B95A5]">
                  Resend code in <span className="font-bold text-[#1E7F43]">{timer}s</span>
                </p>
              ) : (
                <button
                  type="button"
                  onClick={handleResend}
                  className="text-sm text-[#1E7F43] font-semibold hover:underline"
                >
                  Resend Code
                </button>
              )}
            </div>
          </form>
        </div>

        <p className="text-center text-sm text-[#8B95A5] mt-6">
          Step 2 of 4 • OTP Verification
        </p>
      </div>
    </div>
  );
}

export default function BuyerOTPPage() {
  return (
    <Suspense fallback={<Loading />}>
      <BuyerOTPContent />
    </Suspense>
  );
}
