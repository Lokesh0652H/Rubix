'use client';

import React, { useState, useEffect } from "react"
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import Loading from './loading'; // Import the Loading component

export default function FarmerOTPAuth() {
  const searchParams = useSearchParams();
  const phone = searchParams.get('phone') || '';
  const [otp, setOtp] = useState('');
  const [timer, setTimer] = useState(60);
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    if (timer > 0) {
      const interval = setTimeout(() => setTimer(timer - 1), 1000);
      return () => clearTimeout(interval);
    }
  }, [timer]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.length === 6) {
      setIsVerified(true);
      setTimeout(() => {
        window.location.href = `/auth/farmer/camera?phone=${phone}`;
      }, 500);
    }
  };

  return (
    <Suspense fallback={<Loading />}> {/* Wrap the component in a Suspense boundary */}
      <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center p-4">
        <Link
          href={`/auth/farmer/phone`}
          className="fixed top-6 left-6 p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow"
        >
          <ArrowLeft size={20} className="text-[#1E7F43]" />
        </Link>

        <div className="w-full max-w-md animate-fade-in">
          <div className="text-center mb-8 animate-slide-down">
            <h1 className="text-3xl font-bold text-[#1E7F43] mb-2">ArgiSetu</h1>
            <p className="text-[#8B95A5]">Verify Your Number</p>
          </div>

          <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 shadow-sm hover-glow animate-scale-in">
            {/* Progress Indicator */}
            <div className="flex gap-2 mb-8">
              {[1, 2, 3, 4, 5].map((step) => (
                <div
                  key={step}
                  className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                    step <= 2 ? 'bg-[#1E7F43]' : 'bg-[#E8ECEF]'
                  }`}
                />
              ))}
            </div>

            <h2 className="text-2xl font-bold text-[#1F2933] mb-2">Enter OTP</h2>
            <p className="text-[#8B95A5] text-sm mb-6">
              Code sent to <span className="font-semibold text-[#1F2933]">+91 {phone}</span>
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* OTP Input */}
              <div>
                <label className="block text-sm font-semibold text-[#1F2933] mb-3">
                  One-Time Password
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                  placeholder="000000"
                  className="w-full px-4 py-3 text-center text-2xl letter-spacing tracking-widest border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300 placeholder:text-[#8B95A5]"
                />
              </div>

              {/* Timer */}
              <div className="text-center">
                {timer > 0 ? (
                  <p className="text-sm text-[#8B95A5]">
                    Resend code in <span className="font-semibold text-[#1E7F43]">{timer}s</span>
                  </p>
                ) : (
                  <button
                    type="button"
                    onClick={() => setTimer(60)}
                    className="text-sm font-semibold text-[#1E7F43] hover:text-[#165a33] transition-colors"
                  >
                    Resend OTP
                  </button>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={otp.length !== 6 || isVerified}
                className={`w-full py-3 px-4 rounded-lg font-semibold button-ripple transition-all duration-300 ${
                  otp.length === 6 && !isVerified
                    ? 'bg-[#1E7F43] text-white hover:bg-[#165a33] hover:shadow-lg'
                    : 'bg-[#E8ECEF] text-[#8B95A5] cursor-not-allowed'
                }`}
              >
                {isVerified ? (
                  <span className="inline-flex items-center gap-2">
                    <span className="animate-spin-slow">✓</span>
                    Verified!
                  </span>
                ) : (
                  'Verify OTP'
                )}
              </button>
            </form>

            {/* Info Box */}
            <div className="mt-8 p-4 bg-[#F4F8F5] rounded-lg border border-[#A7E3C1]/30 animate-slide-up">
              <p className="text-xs text-[#1F2933]">
                <span className="font-semibold">⏰ Valid for 10 minutes:</span> The OTP will expire after 10 minutes.
              </p>
            </div>
          </div>

          <p className="text-center text-sm text-[#8B95A5] mt-6">
            Step 2 of 5 • OTP Verification
          </p>
        </div>
      </div>
    </Suspense>
  );
}
