'use client';

import React from "react"

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, FileText } from 'lucide-react';

export default function FarmerDocumentsAuth() {
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const documents = [
    { id: 'aadhaar', name: 'Aadhaar Card', icon: '🆔' },
    { id: 'pan', name: 'PAN Card', icon: '📋' },
    { id: 'voter', name: 'Voter ID', icon: '🗳️' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDoc) {
      setIsSubmitted(true);
      setTimeout(() => {
        window.location.href = '/auth/farmer/region';
      }, 500);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center p-4">
      <Link
        href="/auth/farmer/camera"
        className="fixed top-6 left-6 p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow"
      >
        <ArrowLeft size={20} className="text-[#1E7F43]" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-8 animate-slide-down">
          <h1 className="text-3xl font-bold text-[#1E7F43] mb-2">ArgiSetu</h1>
          <p className="text-[#8B95A5]">Verify Identity</p>
        </div>

        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 shadow-sm hover-glow animate-scale-in">
          {/* Progress Indicator */}
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4, 5].map((step) => (
              <div
                key={step}
                className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                  step <= 4 ? 'bg-[#1E7F43]' : 'bg-[#E8ECEF]'
                }`}
              />
            ))}
          </div>

          <h2 className="text-2xl font-bold text-[#1F2933] mb-2">Government ID Proof</h2>
          <p className="text-[#8B95A5] text-sm mb-8">
            Select the ID you&apos;ll use for verification
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Document Selection */}
            {documents.map((doc, idx) => (
              <label
                key={doc.id}
                className="block cursor-pointer animate-slide-up"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <input
                  type="radio"
                  name="document"
                  value={doc.id}
                  checked={selectedDoc === doc.id}
                  onChange={(e) => setSelectedDoc(e.target.value)}
                  className="hidden"
                />
                <div
                  className={`p-4 rounded-lg border-2 transition-all duration-300 flex items-center gap-4 cursor-pointer ${
                    selectedDoc === doc.id
                      ? 'border-[#1E7F43] bg-[#F4F8F5]'
                      : 'border-[#E8ECEF] bg-white hover:border-[#A7E3C1]'
                  }`}
                >
                  <span className="text-3xl">{doc.icon}</span>
                  <div className="flex-1">
                    <p className="font-semibold text-[#1F2933]">{doc.name}</p>
                    <p className="text-xs text-[#8B95A5]">Government-issued ID</p>
                  </div>
                  {selectedDoc === doc.id && (
                    <div className="w-5 h-5 bg-[#1E7F43] rounded-full flex items-center justify-center text-white animate-scale-in">
                      ✓
                    </div>
                  )}
                </div>
              </label>
            ))}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!selectedDoc || isSubmitted}
              className={`w-full py-3 px-4 rounded-lg font-semibold button-ripple transition-all duration-300 mt-6 ${
                selectedDoc && !isSubmitted
                  ? 'bg-[#1E7F43] text-white hover:bg-[#165a33] hover:shadow-lg'
                  : 'bg-[#E8ECEF] text-[#8B95A5] cursor-not-allowed'
              }`}
            >
              {isSubmitted ? (
                <span className="inline-flex items-center gap-2">
                  <span className="animate-spin-slow">⏳</span>
                  Processing...
                </span>
              ) : (
                'Proceed with Selected ID'
              )}
            </button>
          </form>

          {/* Info Box */}
          <div className="mt-8 p-4 bg-[#F4F8F5] rounded-lg border border-[#A7E3C1]/30 animate-slide-up">
            <p className="text-xs text-[#1F2933]">
              <span className="font-semibold">🔐 Secure Upload:</span> Your document will be securely stored and verified by our government-approved partners.
            </p>
          </div>
        </div>

        <p className="text-center text-sm text-[#8B95A5] mt-6">
          Step 4 of 5 • Document Verification
        </p>
      </div>
    </div>
  );
}
