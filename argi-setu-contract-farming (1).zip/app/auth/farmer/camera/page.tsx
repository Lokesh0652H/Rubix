'use client';

import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Camera } from 'lucide-react';

export default function FarmerCameraAuth() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [photoTaken, setPhotoTaken] = useState(false);
  const [photoData, setPhotoData] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;

    if (cameraActive) {
      navigator.mediaDevices
        .getUserMedia({ video: { facingMode: 'user' } })
        .then((mediaStream) => {
          stream = mediaStream;
          if (videoRef.current) {
            videoRef.current.srcObject = mediaStream;
          }
        })
        .catch(() => {
          alert('Camera access is required for verification');
          setCameraActive(false);
        });
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [cameraActive]);

  const handleTakePhoto = () => {
    console.log("[v0] Capture button clicked");
    
    if (!videoRef.current || !canvasRef.current) {
      console.log("[v0] Refs not available");
      alert('Camera not properly initialized. Please try again.');
      return;
    }

    const video = videoRef.current;
    console.log("[v0] Video dimensions:", { width: video.videoWidth, height: video.videoHeight });

    if (video.videoWidth === 0 || video.videoHeight === 0) {
      console.log("[v0] Video not ready yet");
      alert('Camera is still loading. Please wait a moment and try again.');
      return;
    }

    try {
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (!context) {
        console.log("[v0] Canvas context not available");
        alert('Canvas not available. Please try again.');
        return;
      }

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
      
      const imageData = canvas.toDataURL('image/jpeg', 0.95);
      console.log("[v0] Photo captured successfully, data length:", imageData.length);
      
      setPhotoData(imageData);
      setPhotoTaken(true);
    } catch (error) {
      console.log("[v0] Capture error:", error);
      alert('Failed to capture photo. Please try again.');
    }
  };

  const handleContinue = () => {
    // Store photo and continue
    setTimeout(() => {
      window.location.href = '/auth/farmer/documents';
    }, 500);
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center p-4">
      <Link
        href="/auth/farmer/otp"
        className="fixed top-6 left-6 p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow"
      >
        <ArrowLeft size={20} className="text-[#1E7F43]" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <canvas ref={canvasRef} className="hidden" />
        <div className="text-center mb-8 animate-slide-down">
          <h1 className="text-3xl font-bold text-[#1E7F43] mb-2">ArgiSetu</h1>
          <p className="text-[#8B95A5]">Selfie Verification</p>
        </div>

        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 shadow-sm hover-glow animate-scale-in">
          {/* Progress Indicator */}
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4, 5].map((step) => (
              <div
                key={step}
                className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                  step <= 3 ? 'bg-[#1E7F43]' : 'bg-[#E8ECEF]'
                }`}
              />
            ))}
          </div>

          <h2 className="text-2xl font-bold text-[#1F2933] mb-2">Live Selfie</h2>
          <p className="text-[#8B95A5] text-sm mb-6">
            Take a clear photo of your face for verification
          </p>

          {!cameraActive ? (
            <button
              onClick={() => setCameraActive(true)}
              className="w-full py-6 px-4 rounded-lg border-2 border-dashed border-[#1E7F43] bg-[#F4F8F5] hover:bg-[#A7E3C1]/10 transition-all duration-300 flex flex-col items-center gap-3 group animate-slide-up"
            >
              <div className="p-3 bg-[#1E7F43] text-white rounded-full group-hover:scale-110 transition-transform duration-300">
                <Camera size={24} />
              </div>
              <div>
                <p className="font-semibold text-[#1E7F43]">Open Camera</p>
                <p className="text-xs text-[#8B95A5] mt-1">Click to start live capture</p>
              </div>
            </button>
          ) : !photoTaken ? (
            <div className="space-y-4">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                onLoadedMetadata={() => {
                  console.log("[v0] Video loaded:", {
                    width: videoRef.current?.videoWidth,
                    height: videoRef.current?.videoHeight
                  });
                }}
                className="w-full rounded-lg bg-[#1F2933] animate-fade-in"
              />
              <button
                type="button"
                onClick={handleTakePhoto}
                className="w-full py-3 px-4 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300"
              >
                Capture Selfie
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <img
                src={photoData || ''}
                alt="Captured selfie"
                className="w-full rounded-lg border border-[#E8ECEF] animate-fade-in"
              />
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setPhotoTaken(false);
                    setCameraActive(true);
                  }}
                  className="flex-1 py-3 px-4 border-2 border-[#1E7F43] text-[#1E7F43] rounded-lg font-semibold hover:bg-[#F4F8F5] transition-all duration-300"
                >
                  Retake
                </button>
                <button
                  onClick={handleContinue}
                  className="flex-1 py-3 px-4 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {/* Info Box */}
          <div className="mt-8 p-4 bg-[#F4F8F5] rounded-lg border border-[#A7E3C1]/30 animate-slide-up">
            <p className="text-xs text-[#1F2933]">
              <span className="font-semibold">📸 Live Capture Only:</span> We capture photos live from your device camera. No file uploads or gallery selections allowed.
            </p>
          </div>
        </div>

        <p className="text-center text-sm text-[#8B95A5] mt-6">
          Step 3 of 5 • Live Selfie Capture
        </p>
      </div>
    </div>
  );
}
