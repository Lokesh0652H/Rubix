'use client';

import React from "react"

import { useState } from 'react';
import Link from 'next/link';
import { ArrowLeft, MapPin } from 'lucide-react';

export default function FarmerRegionAuth() {
  const [state, setState] = useState('');
  const [district, setDistrict] = useState('');
  const [village, setVillage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const states = [
    'Maharashtra', 'Karnataka', 'Tamil Nadu', 'Uttar Pradesh', 
    'Gujarat', 'Madhya Pradesh', 'Punjab', 'Haryana'
  ];

  const districtMap: { [key: string]: string[] } = {
    Maharashtra: ['Nashik', 'Pune', 'Aurangabad', 'Solapur'],
    Karnataka: ['Belgaum', 'Kolar', 'Shimoga', 'Hassan'],
    'Tamil Nadu': ['Coimbatore', 'Madurai', 'Thanjavur', 'Salem'],
    'Uttar Pradesh': ['Meerut', 'Agra', 'Lucknow', 'Varanasi'],
    Gujarat: ['Ahmedabad', 'Vadodara', 'Surat', 'Rajkot'],
    'Madhya Pradesh': ['Indore', 'Bhopal', 'Jabalpur', 'Ujjain'],
    Punjab: ['Ludhiana', 'Amritsar', 'Jullundur', 'Bathinda'],
    Haryana: ['Hisar', 'Rohtak', 'Faridabad', 'Karnal'],
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (state && district && village) {
      setIsSubmitted(true);
      setTimeout(() => {
        window.location.href = '/dashboard/farmer';
      }, 500);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center p-4">
      <Link
        href="/auth/farmer/documents"
        className="fixed top-6 left-6 p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow"
      >
        <ArrowLeft size={20} className="text-[#1E7F43]" />
      </Link>

      <div className="w-full max-w-md animate-fade-in">
        <div className="text-center mb-8 animate-slide-down">
          <h1 className="text-3xl font-bold text-[#1E7F43] mb-2">ArgiSetu</h1>
          <p className="text-[#8B95A5]">Your Location</p>
        </div>

        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 shadow-sm hover-glow animate-scale-in">
          {/* Progress Indicator */}
          <div className="flex gap-2 mb-8">
            {[1, 2, 3, 4, 5].map((step) => (
              <div
                key={step}
                className={`h-1 flex-1 rounded-full transition-all duration-500 ${
                  step <= 5 ? 'bg-[#1E7F43]' : 'bg-[#E8ECEF]'
                }`}
              />
            ))}
          </div>

          <h2 className="text-2xl font-bold text-[#1F2933] mb-2">Your Location</h2>
          <p className="text-[#8B95A5] text-sm mb-6">
            Help us locate your farm for better market access
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* State Selection */}
            <div className="animate-slide-up">
              <label className="block text-sm font-semibold text-[#1F2933] mb-2">
                <MapPin size={16} className="inline mr-2 text-[#1E7F43]" />
                State
              </label>
              <select
                value={state}
                onChange={(e) => {
                  setState(e.target.value);
                  setDistrict('');
                  setVillage('');
                }}
                className="w-full px-4 py-3 border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300"
              >
                <option value="">Select State</option>
                {states.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>

            {/* District Selection */}
            <div className="animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <label className="block text-sm font-semibold text-[#1F2933] mb-2">
                District
              </label>
              <select
                value={district}
                onChange={(e) => {
                  setDistrict(e.target.value);
                  setVillage('');
                }}
                disabled={!state}
                className="w-full px-4 py-3 border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300 disabled:bg-[#F4F8F5] disabled:text-[#8B95A5]"
              >
                <option value="">Select District</option>
                {state &&
                  districtMap[state]?.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
              </select>
            </div>

            {/* Village/City Input */}
            <div className="animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <label className="block text-sm font-semibold text-[#1F2933] mb-2">
                Village / Town
              </label>
              <input
                type="text"
                value={village}
                onChange={(e) => setVillage(e.target.value)}
                placeholder="Enter your village/town name"
                disabled={!district}
                className="w-full px-4 py-3 border-2 border-[#E8ECEF] rounded-lg focus:border-[#1E7F43] focus:outline-none transition-all duration-300 placeholder:text-[#8B95A5] disabled:bg-[#F4F8F5] disabled:text-[#8B95A5]"
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!state || !district || !village || isSubmitted}
              className={`w-full py-3 px-4 rounded-lg font-semibold button-ripple transition-all duration-300 mt-6 ${
                state && district && village && !isSubmitted
                  ? 'bg-[#1E7F43] text-white hover:bg-[#165a33] hover:shadow-lg'
                  : 'bg-[#E8ECEF] text-[#8B95A5] cursor-not-allowed'
              }`}
            >
              {isSubmitted ? (
                <span className="inline-flex items-center gap-2">
                  <span className="animate-spin-slow">🌾</span>
                  Creating Profile...
                </span>
              ) : (
                'Complete Registration'
              )}
            </button>
          </form>

          {/* Info Box */}
          <div className="mt-8 p-4 bg-[#F4F8F5] rounded-lg border border-[#A7E3C1]/30 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <p className="text-xs text-[#1F2933]">
              <span className="font-semibold">📍 Location Accuracy:</span> Helps us match you with nearby buyers and provide better market insights.
            </p>
          </div>
        </div>

        <p className="text-center text-sm text-[#8B95A5] mt-6">
          Step 5 of 5 • Location Setup
        </p>
      </div>
    </div>
  );
}
