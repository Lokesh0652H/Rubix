'use client';

import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-[#F4F8F5]">
      <div className="max-w-3xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8 animate-fade-in">
          <Link href="/">
            <button className="p-2 hover:bg-white rounded-full transition-all duration-300 hover-glow">
              <ArrowLeft size={20} className="text-[#1E7F43]" />
            </button>
          </Link>
          <h1 className="text-4xl font-bold text-[#1F2933]">Privacy Policy</h1>
        </div>

        {/* Content */}
        <div className="bg-white rounded-2xl border border-[#E8ECEF] p-8 animate-slide-up space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">1. Information We Collect</h2>
            <p className="text-[#8B95A5] leading-relaxed mb-4">
              ArgiSetu collects information to provide and improve our services:
            </p>
            <ul className="text-[#8B95A5] space-y-2 ml-4">
              <li>• Personal information (name, phone, email, address)</li>
              <li>• Government ID information for verification</li>
              <li>• Bank account details for payments</li>
              <li>• Crop and business information</li>
              <li>• Transaction and contract history</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">2. How We Use Your Information</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              We use your information to verify identity, process contracts, manage payments, prevent fraud, and improve our platform. Your data is never shared with third parties without your consent except where required by law.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">3. Data Security</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              We employ industry-standard encryption and security measures to protect your personal information. All sensitive data is stored securely and accessed only by authorized personnel.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">4. Your Rights</h2>
            <p className="text-[#8B95A5] leading-relaxed mb-4">
              You have the right to:
            </p>
            <ul className="text-[#8B95A5] space-y-2 ml-4">
              <li>• Access your personal data</li>
              <li>• Request corrections to inaccurate data</li>
              <li>• Request deletion of your data</li>
              <li>• Opt-out of marketing communications</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">5. Cookies</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              Our platform uses cookies to enhance user experience and track usage patterns. You can control cookie preferences through your browser settings.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">6. Policy Updates</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              We may update this privacy policy periodically. We encourage you to review this page regularly for any changes.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-[#1F2933] mb-4">7. Contact Us</h2>
            <p className="text-[#8B95A5] leading-relaxed">
              If you have privacy concerns, please contact us at privacy@agrisetu.com.
            </p>
          </section>

          <div className="border-t border-[#E8ECEF] pt-6 text-center text-sm text-[#8B95A5]">
            <p>Last Updated: January 2026</p>
          </div>
        </div>
      </div>
    </div>
  );
}
