'use client';

import Link from 'next/link';
import { ArrowLeft, Home } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#F4F8F5] flex items-center justify-center px-4">
      <div className="text-center max-w-md animate-fade-in">
        <div className="text-6xl mb-4">404</div>
        <h1 className="text-4xl font-bold text-[#1F2933] mb-4">Page Not Found</h1>
        <p className="text-[#8B95A5] mb-8">
          The page you're looking for doesn't exist or has been moved.
        </p>
        
        <div className="flex gap-4 justify-center flex-col sm:flex-row">
          <Link href="/">
            <button className="flex items-center justify-center gap-2 px-6 py-3 bg-[#1E7F43] text-white rounded-lg font-semibold button-ripple hover:bg-[#165a33] transition-all duration-300">
              <Home size={18} />
              Go Home
            </button>
          </Link>
          <button
            onClick={() => window.history.back()}
            className="flex items-center justify-center gap-2 px-6 py-3 border border-[#1E7F43] text-[#1E7F43] rounded-lg font-semibold hover:bg-[#F4F8F5] transition-all duration-300"
          >
            <ArrowLeft size={18} />
            Go Back
          </button>
        </div>
      </div>
    </div>
  );
}
