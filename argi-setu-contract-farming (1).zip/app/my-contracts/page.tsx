'use client';

import React, { useState } from 'react';
import Navbar from '@/components/navbar';
import { FileText, Plus, CheckCircle2, Clock, AlertCircle, TrendingUp, Calendar, DollarSign, User } from 'lucide-react';

interface Contract {
  id: string;
  cropName: string;
  buyerName: string;
  quantity: number;
  unit: string;
  agreedPrice: number;
  totalValue: number;
  startDate: string;
  endDate: string;
  deliveryLocation: string;
  status: 'active' | 'completed' | 'pending';
  paymentStatus: 'paid' | 'pending' | 'partial';
  deliveryProgress: number;
}

export default function MyContracts() {
  const [activeTab, setActiveTab] = useState<'active' | 'history' | 'new'>('active');
  const [showNewContract, setShowNewContract] = useState(false);
  const [newContract, setNewContract] = useState({
    cropName: '',
    buyerName: '',
    quantity: '',
    agreedPrice: '',
    deliveryLocation: '',
  });

  const activeContracts: Contract[] = [
    {
      id: '1',
      cropName: 'Wheat HD2967',
      buyerName: 'National Grain Corp',
      quantity: 500,
      unit: 'kg',
      agreedPrice: 2350,
      totalValue: 1175000,
      startDate: '2026-01-15',
      endDate: '2026-02-15',
      deliveryLocation: 'Punjab Warehouse',
      status: 'active',
      paymentStatus: 'partial',
      deliveryProgress: 60,
    },
    {
      id: '2',
      cropName: 'Rice Basmati',
      buyerName: 'Tata Foods Ltd',
      quantity: 1000,
      unit: 'kg',
      agreedPrice: 5200,
      totalValue: 5200000,
      startDate: '2026-01-10',
      endDate: '2026-03-10',
      deliveryLocation: 'Haryana Hub',
      status: 'active',
      paymentStatus: 'paid',
      deliveryProgress: 35,
    },
  ];

  const completedContracts: Contract[] = [
    {
      id: '3',
      cropName: 'Cotton MCU5',
      buyerName: 'Texile Industries',
      quantity: 750,
      unit: 'kg',
      agreedPrice: 6100,
      totalValue: 4575000,
      startDate: '2025-12-01',
      endDate: '2026-01-05',
      deliveryLocation: 'Gujarat Warehouse',
      status: 'completed',
      paymentStatus: 'paid',
      deliveryProgress: 100,
    },
    {
      id: '4',
      cropName: 'Maize Hybrid',
      buyerName: 'Poultry Feed Co',
      quantity: 300,
      unit: 'kg',
      agreedPrice: 2000,
      totalValue: 600000,
      startDate: '2025-11-15',
      endDate: '2025-12-20',
      deliveryLocation: 'Rajasthan Center',
      status: 'completed',
      paymentStatus: 'paid',
      deliveryProgress: 100,
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-blue-100 text-blue-700';
      case 'completed':
        return 'bg-green-100 text-[#1E7F43]';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getPaymentStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <CheckCircle2 size={20} className="text-[#1E7F43]" />;
      case 'pending':
        return <Clock size={20} className="text-yellow-600" />;
      case 'partial':
        return <AlertCircle size={20} className="text-orange-600" />;
      default:
        return null;
    }
  };

  const handleCreateContract = () => {
    if (newContract.cropName && newContract.quantity && newContract.agreedPrice) {
      alert('Contract created successfully!');
      setNewContract({ cropName: '', buyerName: '', quantity: '', agreedPrice: '', deliveryLocation: '' });
      setShowNewContract(false);
      setActiveTab('active');
    }
  };

  const ContractCard = ({ contract, idx }: { contract: Contract; idx: number }) => (
    <div
      className="bg-white rounded-xl border border-[#E8ECEF] p-6 hover-lift transition-all duration-300 animate-slide-up"
      style={{ animationDelay: `${idx * 0.1}s` }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-[#1F2933]">{contract.cropName}</h3>
          <p className="text-sm text-[#8B95A5] flex items-center gap-2 mt-1">
            <User size={16} />
            {contract.buyerName}
          </p>
        </div>
        <div className={`px-3 py-1 rounded-full text-sm font-semibold capitalize ${getStatusColor(contract.status)}`}>
          {contract.status}
        </div>
      </div>

      {/* Details Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 pb-6 border-b border-[#E8ECEF]">
        <div>
          <p className="text-xs text-[#8B95A5] mb-1">Quantity</p>
          <p className="font-semibold text-[#1F2933]">{contract.quantity} {contract.unit}</p>
        </div>
        <div>
          <p className="text-xs text-[#8B95A5] mb-1">Agreed Price</p>
          <p className="font-semibold text-[#1F2933]">₹{contract.agreedPrice}/kg</p>
        </div>
        <div>
          <p className="text-xs text-[#8B95A5] mb-1">Total Value</p>
          <p className="font-bold text-[#1E7F43]">₹{contract.totalValue.toLocaleString()}</p>
        </div>
        <div>
          <p className="text-xs text-[#8B95A5] mb-1">Payment</p>
          <div className="flex items-center gap-2">
            {getPaymentStatusIcon(contract.paymentStatus)}
            <span className="text-sm font-semibold capitalize text-[#1F2933]">{contract.paymentStatus}</span>
          </div>
        </div>
      </div>

      {/* Delivery Progress */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-semibold text-[#1F2933]">Delivery Progress</p>
          <p className="text-sm font-bold text-[#1E7F43]">{contract.deliveryProgress}%</p>
        </div>
        <div className="w-full bg-[#E8ECEF] rounded-full h-2 overflow-hidden">
          <div
            className="h-full bg-[#1E7F43] rounded-full transition-all duration-500 animate-slide-in-right"
            style={{ width: `${contract.deliveryProgress}%` }}
          />
        </div>
      </div>

      {/* Dates */}
      <div className="grid grid-cols-2 gap-4 text-sm text-[#8B95A5]">
        <div className="flex items-center gap-2">
          <Calendar size={16} />
          <span>Start: {contract.startDate}</span>
        </div>
        <div className="flex items-center gap-2">
          <Calendar size={16} />
          <span>End: {contract.endDate}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="farmer" userName="Harjeet" />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">My Contracts</h1>
          <p className="text-[#8B95A5]">Manage your active contracts and view contract history</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8 border-b border-[#E8ECEF] animate-slide-up">
          {[
            { id: 'active', label: 'Active Contracts', icon: Clock },
            { id: 'history', label: 'Contract History', icon: FileText },
            { id: 'new', label: 'New Contract', icon: Plus },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 font-semibold transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'text-[#1E7F43] border-b-2 border-[#1E7F43]'
                    : 'text-[#8B95A5] hover:text-[#1F2933]'
                }`}
              >
                <Icon size={20} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Active Contracts */}
        {activeTab === 'active' && (
          <div className="space-y-6 animate-fade-in">
            {activeContracts.map((contract, idx) => (
              <ContractCard key={contract.id} contract={contract} idx={idx} />
            ))}
          </div>
        )}

        {/* Contract History */}
        {activeTab === 'history' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-[#A7E3C1]/20 border border-[#6BCF9B] rounded-lg p-4 mb-6 flex items-center gap-3">
              <CheckCircle2 size={24} className="text-[#1E7F43]" />
              <div>
                <p className="font-semibold text-[#1F2933]">Completed Contracts</p>
                <p className="text-sm text-[#8B95A5]">View your past successful transactions</p>
              </div>
            </div>
            {completedContracts.map((contract, idx) => (
              <ContractCard key={contract.id} contract={contract} idx={idx} />
            ))}
          </div>
        )}

        {/* New Contract */}
        {activeTab === 'new' && (
          <div className="max-w-2xl bg-white rounded-xl border border-[#E8ECEF] p-8 animate-scale-in">
            <h2 className="text-2xl font-bold text-[#1F2933] mb-6">Create New Contract</h2>

            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-[#1F2933] mb-2">Crop Name</label>
                <input
                  type="text"
                  placeholder="e.g., Wheat"
                  value={newContract.cropName}
                  onChange={(e) => setNewContract({ ...newContract, cropName: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#1F2933] mb-2">Buyer Name</label>
                <input
                  type="text"
                  placeholder="e.g., National Grain Corp"
                  value={newContract.buyerName}
                  onChange={(e) => setNewContract({ ...newContract, buyerName: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-[#1F2933] mb-2">Quantity (kg)</label>
                  <input
                    type="number"
                    placeholder="500"
                    value={newContract.quantity}
                    onChange={(e) => setNewContract({ ...newContract, quantity: e.target.value })}
                    className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#1F2933] mb-2">Agreed Price (₹/kg)</label>
                  <input
                    type="number"
                    placeholder="2350"
                    value={newContract.agreedPrice}
                    onChange={(e) => setNewContract({ ...newContract, agreedPrice: e.target.value })}
                    className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#1F2933] mb-2">Delivery Location</label>
                <input
                  type="text"
                  placeholder="e.g., Punjab Warehouse"
                  value={newContract.deliveryLocation}
                  onChange={(e) => setNewContract({ ...newContract, deliveryLocation: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                />
              </div>

              <button
                onClick={handleCreateContract}
                className="w-full py-3 px-4 bg-[#1E7F43] text-white font-semibold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 mt-6"
              >
                Create Contract
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
