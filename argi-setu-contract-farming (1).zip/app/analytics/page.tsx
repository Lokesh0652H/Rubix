'use client';

import React, { useState } from 'react';
import Navbar from '@/components/navbar';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, ShoppingCart, Calendar } from 'lucide-react';

export default function Analytics() {
  const [timeRange, setTimeRange] = useState('6m');

  // Monthly revenue data
  const revenueData = [
    { month: 'Jul', revenue: 240000, contracts: 3 },
    { month: 'Aug', revenue: 380000, contracts: 5 },
    { month: 'Sep', revenue: 290000, contracts: 4 },
    { month: 'Oct', revenue: 420000, contracts: 6 },
    { month: 'Nov', revenue: 510000, contracts: 7 },
    { month: 'Dec', revenue: 680000, contracts: 9 },
    { month: 'Jan', revenue: 720000, contracts: 10 },
  ];

  // Crop distribution
  const cropData = [
    { name: 'Wheat', value: 35, revenue: 2520000 },
    { name: 'Rice', value: 28, revenue: 2016000 },
    { name: 'Cotton', value: 22, revenue: 1584000 },
    { name: 'Maize', value: 15, revenue: 1080000 },
  ];

  // Price trends
  const priceData = [
    { date: 'Jan 1', wheat: 2200, rice: 4500, cotton: 5800 },
    { date: 'Jan 8', wheat: 2250, rice: 4600, cotton: 5900 },
    { date: 'Jan 15', wheat: 2300, rice: 4750, cotton: 6000 },
    { date: 'Jan 22', wheat: 2350, rice: 5000, cotton: 6100 },
    { date: 'Jan 29', wheat: 2400, rice: 5150, cotton: 6050 },
  ];

  const COLORS = ['#1E7F43', '#6BCF9B', '#A7E3C1', '#8B95A5'];

  const StatCard = ({ icon: Icon, label, value, change, positive }: any) => (
    <div className="bg-white rounded-xl border border-[#E8ECEF] p-6 hover-lift transition-all duration-300 animate-slide-up">
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 bg-[#F4F8F5] rounded-lg">
          <Icon size={24} className="text-[#1E7F43]" />
        </div>
        <div className={`flex items-center gap-1 ${positive ? 'text-[#1E7F43]' : 'text-[#DC2626]'}`}>
          {positive ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
          <span className="font-semibold text-sm">{change}%</span>
        </div>
      </div>
      <p className="text-[#8B95A5] text-sm mb-1">{label}</p>
      <p className="text-2xl font-bold text-[#1F2933]">{value}</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="farmer" userName="Harjeet" />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div>
              <h1 className="text-4xl font-bold text-[#1F2933]">Analytics Dashboard</h1>
              <p className="text-[#8B95A5] mt-2">Track your sales, revenue, and market trends</p>
            </div>
            <div className="flex gap-2">
              {['1m', '3m', '6m', '1y'].map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                    timeRange === range
                      ? 'bg-[#1E7F43] text-white'
                      : 'bg-white text-[#8B95A5] border border-[#E8ECEF] hover:border-[#1E7F43]'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard icon={DollarSign} label="Total Revenue" value="₹33.85L" change="12.5" positive={true} />
          <StatCard icon={ShoppingCart} label="Total Contracts" value="44" change="8.2" positive={true} />
          <StatCard icon={Calendar} label="Active Listings" value="8" change="-2.1" positive={false} />
          <StatCard icon={TrendingUp} label="Avg Price (₹/kg)" value="₹3,850" change="5.3" positive={true} />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Revenue & Contracts Trend */}
          <div className="bg-white rounded-xl border border-[#E8ECEF] p-6 animate-slide-up">
            <h2 className="text-lg font-bold text-[#1F2933] mb-6">Revenue & Contracts Trend</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8ECEF" />
                <XAxis dataKey="month" stroke="#8B95A5" />
                <YAxis stroke="#8B95A5" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E8ECEF',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="revenue"
                  stroke="#1E7F43"
                  strokeWidth={2}
                  name="Revenue (₹)"
                  dot={{ fill: '#1E7F43', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Crop Distribution */}
          <div className="bg-white rounded-xl border border-[#E8ECEF] p-6 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            <h2 className="text-lg font-bold text-[#1F2933] mb-6">Crop Distribution by Revenue</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={cropData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name} ${value}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {cropData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Price Trends & Contracts History */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Price Trends Chart */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-[#E8ECEF] p-6 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <h2 className="text-lg font-bold text-[#1F2933] mb-6">Market Price Trends</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={priceData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E8ECEF" />
                <XAxis dataKey="date" stroke="#8B95A5" />
                <YAxis stroke="#8B95A5" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#FFFFFF',
                    border: '1px solid #E8ECEF',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="wheat"
                  stroke="#1E7F43"
                  strokeWidth={2}
                  name="Wheat (₹/kg)"
                  dot={{ fill: '#1E7F43', r: 3 }}
                />
                <Line
                  type="monotone"
                  dataKey="rice"
                  stroke="#6BCF9B"
                  strokeWidth={2}
                  name="Rice (₹/kg)"
                  dot={{ fill: '#6BCF9B', r: 3 }}
                />
                <Line
                  type="monotone"
                  dataKey="cotton"
                  stroke="#A7E3C1"
                  strokeWidth={2}
                  name="Cotton (₹/kg)"
                  dot={{ fill: '#A7E3C1', r: 3 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Top Buyers */}
          <div className="bg-white rounded-xl border border-[#E8ECEF] p-6 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <h2 className="text-lg font-bold text-[#1F2933] mb-6">Top Buyers</h2>
            <div className="space-y-4">
              {[
                { name: 'National Grain Corp', value: '₹12.5L', icon: '🏢' },
                { name: 'Tata Foods Ltd', value: '₹8.2L', icon: '🏭' },
                { name: 'Textile Industries', value: '₹7.8L', icon: '🏗️' },
                { name: 'Poultry Feed Co', value: '₹5.4L', icon: '🐔' },
              ].map((buyer, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3 p-3 bg-[#F4F8F5] rounded-lg hover:bg-[#A7E3C1]/20 transition-all duration-300 animate-fade-in"
                  style={{ animationDelay: `${0.1 * idx}s` }}
                >
                  <span className="text-xl">{buyer.icon}</span>
                  <div className="flex-1">
                    <p className="font-semibold text-[#1F2933] text-sm">{buyer.name}</p>
                    <p className="text-xs text-[#8B95A5]">Total Revenue</p>
                  </div>
                  <p className="font-bold text-[#1E7F43]">{buyer.value}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
