'use client';

import React, { useState } from 'react';
import Navbar from '@/components/navbar';
import { TrendingUp, ShoppingCart, MapPin, User, Calendar, DollarSign, Plus, ArrowUp, Filter } from 'lucide-react';

interface CropListing {
  id: string;
  cropName: string;
  variety: string;
  quantity: string;
  unit: string;
  minPrice: number;
  currentBid: number;
  bidCount: number;
  location: string;
  harvestDate: string;
  image: string;
  seller: string;
  timeLeft: string;
}

interface ActiveBid {
  id: string;
  cropName: string;
  myBid: number;
  highestBid: number;
  status: 'winning' | 'outbid' | 'closed';
}

export default function Marketplace() {
  const [activeTab, setActiveTab] = useState<'browse' | 'myBids' | 'listCrop'>('browse');
  const [sortBy, setSortBy] = useState('trending');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [newListing, setNewListing] = useState({
    cropName: '',
    variety: '',
    quantity: '',
    minPrice: '',
  });

  const cropListings: CropListing[] = [
    {
      id: '1',
      cropName: 'Wheat',
      variety: 'HD2967',
      quantity: '500',
      unit: 'kg',
      minPrice: 2200,
      currentBid: 2450,
      bidCount: 8,
      location: 'Punjab',
      harvestDate: '2026-02-15',
      image: '/crops/wheat.jpg',
      seller: 'Farmer Singh',
      timeLeft: '2 days',
    },
    {
      id: '2',
      cropName: 'Rice',
      variety: 'Basmati',
      quantity: '1000',
      unit: 'kg',
      minPrice: 4500,
      currentBid: 5200,
      bidCount: 12,
      location: 'Haryana',
      harvestDate: '2026-01-20',
      image: '/crops/rice.jpg',
      seller: 'Farmer Kumar',
      timeLeft: '4 hours',
    },
    {
      id: '3',
      cropName: 'Cotton',
      variety: 'MCU5',
      quantity: '750',
      unit: 'kg',
      minPrice: 5800,
      currentBid: 6100,
      bidCount: 5,
      location: 'Gujarat',
      harvestDate: '2026-03-10',
      image: '/crops/cotton.jpg',
      seller: 'Farmer Patel',
      timeLeft: '1 day',
    },
    {
      id: '4',
      cropName: 'Maize',
      variety: 'Hybrid',
      quantity: '300',
      unit: 'kg',
      minPrice: 1800,
      currentBid: 2000,
      bidCount: 3,
      location: 'Rajasthan',
      harvestDate: '2026-02-28',
      image: '/crops/wheat.jpg',
      seller: 'Farmer Sharma',
      timeLeft: '6 days',
    },
  ];

  const myBids: ActiveBid[] = [
    {
      id: '1',
      cropName: 'Wheat HD2967',
      myBid: 2350,
      highestBid: 2450,
      status: 'outbid',
    },
    {
      id: '2',
      cropName: 'Rice Basmati',
      myBid: 5200,
      highestBid: 5200,
      status: 'winning',
    },
  ];

  const handlePlaceBid = (cropId: string) => {
    alert(`Bid placed on crop ${cropId}`);
  };

  const handleListCrop = () => {
    if (newListing.cropName && newListing.quantity && newListing.minPrice) {
      alert('Crop listed successfully!');
      setNewListing({ cropName: '', variety: '', quantity: '', minPrice: '' });
      setActiveTab('browse');
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F8F5] pt-20">
      <Navbar userType="farmer" userName="Harjeet" />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8 animate-fade-in">
          <h1 className="text-4xl font-bold text-[#1F2933] mb-2">Marketplace</h1>
          <p className="text-[#8B95A5]">Browse available crops or list your harvest for bidding</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex gap-4 mb-8 border-b border-[#E8ECEF] animate-slide-up">
          {[
            { id: 'browse', label: 'Browse Crops', icon: ShoppingCart },
            { id: 'myBids', label: 'My Bids', icon: TrendingUp },
            { id: 'listCrop', label: 'List Crop', icon: Plus },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 font-semibold transition-all duration-300 ${
                  activeTab === tab.id
                    ? 'text-[#1E7F43] border-b-2 border-[#1E7F43]'
                    : 'text-[#8B95A5] hover:text-[#1F2933]'
                }`}
              >
                <Icon size={20} />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Browse Crops Tab */}
        {activeTab === 'browse' && (
          <div className="space-y-6 animate-fade-in">
            {/* Filters */}
            <div className="flex gap-3 flex-wrap">
              <button className="flex items-center gap-2 px-4 py-2 bg-white border border-[#E8ECEF] rounded-lg hover:border-[#1E7F43] hover:text-[#1E7F43] transition-all duration-300">
                <Filter size={18} />
                <span className="text-sm font-medium">All Crops</span>
              </button>
              {['Wheat', 'Rice', 'Cotton', 'Maize'].map((crop) => (
                <button
                  key={crop}
                  className="px-4 py-2 bg-white border border-[#E8ECEF] rounded-lg text-sm font-medium text-[#8B95A5] hover:text-[#1E7F43] hover:border-[#1E7F43] transition-all duration-300"
                >
                  {crop}
                </button>
              ))}
            </div>

            {/* Crop Listings Grid - 50-50 Split */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {cropListings.map((crop, idx) => (
                <div
                  key={crop.id}
                  className="bg-white rounded-xl border border-[#E8ECEF] overflow-hidden hover-lift hover:shadow-lg transition-all duration-300 animate-slide-up group"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  {/* Image Area */}
                  <div className="h-48 bg-[#E8ECEF] relative overflow-hidden group-hover:scale-105 transition-transform duration-300">
                    <img 
                      src={crop.image || "/placeholder.svg"} 
                      alt={crop.cropName}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 right-4 bg-[#1E7F43] text-white px-3 py-1 rounded-full text-sm font-semibold animate-pulse-soft">
                      {crop.timeLeft}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    {/* Crop Info */}
                    <div className="mb-4">
                      <h3 className="text-xl font-bold text-[#1F2933] mb-1">{crop.cropName}</h3>
                      <p className="text-sm text-[#8B95A5] mb-3">{crop.variety} • {crop.quantity} {crop.unit}</p>

                      {/* Details Grid */}
                      <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
                        <div className="flex items-center gap-2 text-[#8B95A5]">
                          <MapPin size={16} className="text-[#1E7F43]" />
                          {crop.location}
                        </div>
                        <div className="flex items-center gap-2 text-[#8B95A5]">
                          <Calendar size={16} className="text-[#1E7F43]" />
                          {crop.harvestDate}
                        </div>
                        <div className="flex items-center gap-2 text-[#8B95A5]">
                          <User size={16} className="text-[#1E7F43]" />
                          {crop.seller}
                        </div>
                        <div className="flex items-center gap-2 text-[#8B95A5]">
                          <TrendingUp size={16} className="text-[#1E7F43]" />
                          {crop.bidCount} bids
                        </div>
                      </div>
                    </div>

                    {/* Pricing */}
                    <div className="bg-[#F4F8F5] p-4 rounded-lg mb-4">
                      <div className="flex justify-between mb-2">
                        <span className="text-sm text-[#8B95A5]">Min Price</span>
                        <span className="font-semibold text-[#1F2933]">₹{crop.minPrice}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-[#1E7F43] font-semibold">Current Bid</span>
                        <span className="font-bold text-[#1E7F43] text-lg">₹{crop.currentBid}</span>
                      </div>
                    </div>

                    {/* Action Button */}
                    <button
                      onClick={() => handlePlaceBid(crop.id)}
                      className="w-full py-3 px-4 bg-[#1E7F43] text-white font-semibold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 flex items-center justify-center gap-2"
                    >
                      <ArrowUp size={18} />
                      Place Bid
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* My Bids Tab */}
        {activeTab === 'myBids' && (
          <div className="space-y-4 animate-fade-in">
            {myBids.map((bid, idx) => (
              <div
                key={bid.id}
                className="bg-white rounded-xl border border-[#E8ECEF] p-6 hover-lift transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${idx * 0.1}s` }}
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-[#1F2933] mb-2">{bid.cropName}</h3>
                    <div className="flex gap-6">
                      <div>
                        <p className="text-sm text-[#8B95A5] mb-1">Your Bid</p>
                        <p className="text-xl font-bold text-[#1F2933]">₹{bid.myBid}</p>
                      </div>
                      <div>
                        <p className="text-sm text-[#8B95A5] mb-1">Highest Bid</p>
                        <p className="text-xl font-bold text-[#1E7F43]">₹{bid.highestBid}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className={`px-4 py-2 rounded-lg font-semibold ${
                      bid.status === 'winning'
                        ? 'bg-green-100 text-[#1E7F43]'
                        : 'bg-red-100 text-[#DC2626]'
                    }`}>
                      {bid.status === 'winning' ? 'Winning' : 'Outbid'}
                    </div>
                    {bid.status === 'outbid' && (
                      <button className="px-4 py-2 bg-[#1E7F43] text-white font-semibold rounded-lg hover:bg-[#165a33] transition-all duration-300 button-ripple">
                        Raise Bid
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* List Crop Tab */}
        {activeTab === 'listCrop' && (
          <div className="max-w-2xl bg-white rounded-xl border border-[#E8ECEF] p-8 animate-scale-in">
            <h2 className="text-2xl font-bold text-[#1F2933] mb-6">List Your Crop for Bidding</h2>

            <div className="space-y-5">
              <div>
                <label className="block text-sm font-semibold text-[#1F2933] mb-2">Crop Name</label>
                <input
                  type="text"
                  placeholder="e.g., Wheat, Rice, Cotton"
                  value={newListing.cropName}
                  onChange={(e) => setNewListing({ ...newListing, cropName: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#1F2933] mb-2">Variety</label>
                <input
                  type="text"
                  placeholder="e.g., Basmati, HD2967"
                  value={newListing.variety}
                  onChange={(e) => setNewListing({ ...newListing, variety: e.target.value })}
                  className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-[#1F2933] mb-2">Quantity (kg)</label>
                  <input
                    type="number"
                    placeholder="500"
                    value={newListing.quantity}
                    onChange={(e) => setNewListing({ ...newListing, quantity: e.target.value })}
                    className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#1F2933] mb-2">Min Price (₹/kg)</label>
                  <input
                    type="number"
                    placeholder="2200"
                    value={newListing.minPrice}
                    onChange={(e) => setNewListing({ ...newListing, minPrice: e.target.value })}
                    className="w-full px-4 py-2 border border-[#E8ECEF] rounded-lg focus:ring-2 focus:ring-[#1E7F43] focus:border-transparent outline-none transition-all duration-300"
                  />
                </div>
              </div>

              <button
                onClick={handleListCrop}
                className="w-full py-3 px-4 bg-[#1E7F43] text-white font-semibold rounded-lg button-ripple hover:bg-[#165a33] transition-all duration-300 mt-6"
              >
                List Crop
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
